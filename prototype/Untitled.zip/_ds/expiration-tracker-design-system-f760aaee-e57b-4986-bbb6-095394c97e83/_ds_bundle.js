/* @ds-bundle: {"format":4,"namespace":"ExpirationTrackerDesignSystem_f760aa","components":[{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"ButtonLink","sourcePath":"components/core/ButtonLink.jsx"},{"name":"Icon","sourcePath":"components/core/Icon.jsx"},{"name":"InlineNotice","sourcePath":"components/core/InlineNotice.jsx"},{"name":"StatusBadge","sourcePath":"components/core/StatusBadge.jsx"},{"name":"UrgencyIndicator","sourcePath":"components/core/UrgencyIndicator.jsx"},{"name":"DataTable","sourcePath":"components/data/DataTable.jsx"},{"name":"CellSecondary","sourcePath":"components/data/DataTable.jsx"},{"name":"AsyncFeedback","sourcePath":"components/feedback/AsyncFeedback.jsx"},{"name":"BackgroundRefreshIndicator","sourcePath":"components/feedback/BackgroundRefreshIndicator.jsx"},{"name":"CollectionSkeleton","sourcePath":"components/feedback/CollectionSkeleton.jsx"},{"name":"EmptyState","sourcePath":"components/feedback/EmptyState.jsx"},{"name":"ErrorState","sourcePath":"components/feedback/ErrorState.jsx"},{"name":"InitialLoading","sourcePath":"components/feedback/InitialLoading.jsx"},{"name":"FormErrorSummary","sourcePath":"components/forms/FormErrorSummary.jsx"},{"name":"TextField","sourcePath":"components/forms/TextField.jsx"},{"name":"DetailList","sourcePath":"components/layout/DetailList.jsx"},{"name":"FilterGroup","sourcePath":"components/layout/FilterGroup.jsx"},{"name":"PageHeader","sourcePath":"components/layout/PageHeader.jsx"},{"name":"Panel","sourcePath":"components/layout/Panel.jsx"},{"name":"Section","sourcePath":"components/layout/Section.jsx"},{"name":"Toolbar","sourcePath":"components/layout/Toolbar.jsx"},{"name":"ToolbarSpacer","sourcePath":"components/layout/Toolbar.jsx"},{"name":"AppShell","sourcePath":"components/shell/AppShell.jsx"}],"sourceHashes":{"components/core/Button.jsx":"080442b0928e","components/core/ButtonLink.jsx":"7fc029db7efa","components/core/Icon.jsx":"76fc24a121eb","components/core/InlineNotice.jsx":"f679da3508b3","components/core/StatusBadge.jsx":"2b08433894d7","components/core/UrgencyIndicator.jsx":"aac5ebe32b94","components/data/DataTable.jsx":"43c78ad375e9","components/feedback/AsyncFeedback.jsx":"06d433f8d758","components/feedback/BackgroundRefreshIndicator.jsx":"34a2ba13e75d","components/feedback/CollectionSkeleton.jsx":"3717f332e4dc","components/feedback/EmptyState.jsx":"615d03bd95e5","components/feedback/ErrorState.jsx":"348c3654a40c","components/feedback/InitialLoading.jsx":"5fb07404aa44","components/forms/FormErrorSummary.jsx":"be291340dbe3","components/forms/TextField.jsx":"354edacbea62","components/layout/DetailList.jsx":"cc64c63d85e2","components/layout/FilterGroup.jsx":"5860ac8ba66e","components/layout/PageHeader.jsx":"79fdca9a2563","components/layout/Panel.jsx":"b35dad4229e7","components/layout/Section.jsx":"fc7792b78a1f","components/layout/Toolbar.jsx":"2400fc85f719","components/shell/AppShell.jsx":"7f482401f24e","ui_kits/webapp/CollectionScreens-v2.jsx":"41402bdb48cc","ui_kits/webapp/CollectionScreens.jsx":"f9c7de99ed26","ui_kits/webapp/DocumentAndAlertScreens-v2.jsx":"de66d8cfc9a4","ui_kits/webapp/GuestScreen-v2.jsx":"7d91ffe70cfd","ui_kits/webapp/RecordScreens-v2.jsx":"e56aac814206","ui_kits/webapp/RecordScreens.jsx":"37ba4d83eaa2","ui_kits/webapp/SettingsAndImportScreens-v2.jsx":"fbb6a4241d2e","ui_kits/webapp/SubjectScreens-v2.jsx":"6aaebb02c634","ui_kits/webapp/app-v2.jsx":"fb71f3d5a280","ui_kits/webapp/app.jsx":"0fd0f144af81","ui_kits/webapp/data-subjects.jsx":"bee5729d4a1b","ui_kits/webapp/data.jsx":"af6ec8095023","ui_kits/webapp/icon.jsx":"b6d221559938","ui_kits/webapp/ui-v2.jsx":"431dc09e6c19","ui_kits/webapp/ui.jsx":"a59cd8dee742"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.ExpirationTrackerDesignSystem_f760aa = window.ExpirationTrackerDesignSystem_f760aa || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/core/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Button — a real <button> for mutations/actions. Never a styled <div>, and never used for
 * navigation (that is ButtonLink). The variant describes INTENT, never appearance.
 */
function Button({
  variant = "secondary",
  size = "md",
  pending,
  disabled,
  type = "button",
  children,
  ...rest
}) {
  const className = ["ui-button", `ui-button--${variant}`, size === "sm" ? "ui-button--sm" : ""].filter(Boolean).join(" ");
  return /*#__PURE__*/React.createElement("button", _extends({}, rest, {
    type: type,
    className: className,
    disabled: Boolean(disabled || pending),
    "data-pending": pending ? "true" : undefined,
    "aria-busy": pending ? true : undefined
  }), children);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/core/ButtonLink.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * ButtonLink — a real <a> that looks like a button, for navigation that merely LOOKS like an
 * action. The product renders this as a react-router <Link>; the design system uses a plain
 * anchor with the same classes.
 */
function ButtonLink({
  variant = "secondary",
  size = "md",
  href = "#",
  children,
  ...rest
}) {
  const className = ["ui-button", `ui-button--${variant}`, size === "sm" ? "ui-button--sm" : "", "ui-button--as-link"].filter(Boolean).join(" ");
  return /*#__PURE__*/React.createElement("a", _extends({}, rest, {
    href: href,
    className: className
  }), children);
}
Object.assign(__ds_scope, { ButtonLink });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/ButtonLink.jsx", error: String((e && e.message) || e) }); }

// components/core/Icon.jsx
try { (() => {
/* Internal helper, not a public component (no sibling .d.ts): a tiny fixed icon set (Lucide
   paths, ISC-licensed) used by StatusBadge/InlineNotice for their tone markers. Not meant to be
   imported directly by consumers — request a name to be added here rather than reaching for a
   bigger icon library import at the call site. */
const PATHS = {
  dot: /*#__PURE__*/React.createElement("circle", {
    cx: "12",
    cy: "12",
    r: "9",
    fill: "currentColor",
    stroke: "none"
  }),
  info: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("circle", {
    cx: "12",
    cy: "12",
    r: "10"
  }), /*#__PURE__*/React.createElement("line", {
    x1: "12",
    y1: "16",
    x2: "12",
    y2: "12"
  }), /*#__PURE__*/React.createElement("line", {
    x1: "12",
    y1: "8",
    x2: "12.01",
    y2: "8"
  })),
  "check-circle": /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("path", {
    d: "M22 11.08V12a10 10 0 1 1-5.93-9.14"
  }), /*#__PURE__*/React.createElement("polyline", {
    points: "22 4 12 14.01 9 11.01"
  })),
  "alert-triangle": /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("path", {
    d: "m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z"
  }), /*#__PURE__*/React.createElement("line", {
    x1: "12",
    y1: "9",
    x2: "12",
    y2: "13"
  }), /*#__PURE__*/React.createElement("line", {
    x1: "12",
    y1: "17",
    x2: "12.01",
    y2: "17"
  })),
  "x-circle": /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("circle", {
    cx: "12",
    cy: "12",
    r: "10"
  }), /*#__PURE__*/React.createElement("line", {
    x1: "15",
    y1: "9",
    x2: "9",
    y2: "15"
  }), /*#__PURE__*/React.createElement("line", {
    x1: "9",
    y1: "9",
    x2: "15",
    y2: "15"
  }))
};
function Icon({
  name,
  size = 14
}) {
  return /*#__PURE__*/React.createElement("svg", {
    width: size,
    height: size,
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "2",
    strokeLinecap: "round",
    strokeLinejoin: "round",
    "aria-hidden": "true",
    focusable: "false"
  }, PATHS[name] || PATHS.dot);
}
Object.assign(__ds_scope, { Icon });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Icon.jsx", error: String((e && e.message) || e) }); }

// components/core/InlineNotice.jsx
try { (() => {
const TONE_ICON = {
  neutral: "dot",
  info: "info",
  success: "check-circle",
  warning: "alert-triangle",
  critical: "x-circle"
};

/**
 * InlineNotice — persistent page/section feedback. Normal flow content, never a toast, so
 * important information can never disappear on a timer. An unconfirmed outcome is rendered
 * `warning`, never `critical`.
 */
function InlineNotice({
  tone = "info",
  title,
  children,
  actions,
  announce = "none"
}) {
  const role = announce === "none" ? undefined : announce;
  return /*#__PURE__*/React.createElement("div", {
    className: `ui-notice ui-notice--${tone}`,
    role: role,
    "aria-live": announce === "status" ? "polite" : undefined
  }, /*#__PURE__*/React.createElement("span", {
    className: "ui-notice__marker"
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: TONE_ICON[tone],
    size: 18
  })), /*#__PURE__*/React.createElement("div", {
    className: "ui-notice__body"
  }, title ? /*#__PURE__*/React.createElement("p", {
    className: "ui-notice__title"
  }, title) : null, children, actions ? /*#__PURE__*/React.createElement("div", {
    className: "ui-notice__actions"
  }, actions) : null));
}
Object.assign(__ds_scope, { InlineNotice });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/InlineNotice.jsx", error: String((e && e.message) || e) }); }

// components/core/StatusBadge.jsx
try { (() => {
/**
 * StatusBadge — a compact, non-interactive attribute of a record. Three cues always: text
 * label, shape marker, color. In the product the tone is never chosen at the call site: it
 * comes from api/presentation.ts, so a screen cannot claim a friendlier state than the domain
 * supports.
 */
const TONE_ICON = {
  neutral: "dot",
  info: "info",
  success: "check-circle",
  warning: "alert-triangle",
  critical: "x-circle"
};
function StatusBadge({
  label,
  tone = "neutral",
  srPrefix,
  wrap
}) {
  return /*#__PURE__*/React.createElement("span", {
    className: `ui-badge ui-badge--${tone}${wrap ? " ui-badge--wrap" : ""}`,
    "data-tone": tone
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: TONE_ICON[tone],
    size: 12
  }), srPrefix ? /*#__PURE__*/React.createElement("span", {
    className: "u-visually-hidden"
  }, srPrefix, ": ") : null, label);
}
Object.assign(__ds_scope, { StatusBadge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/StatusBadge.jsx", error: String((e && e.message) || e) }); }

// components/core/UrgencyIndicator.jsx
try { (() => {
/**
 * UrgencyIndicator — urgency is NOT status, and both must be showable at once without
 * ambiguity ("Urgência: Vence em 3 dias" + "Situação: Ativo"). Reuses the badge shape rather
 * than inventing a second vocabulary for "a compact semantic attribute".
 */
function UrgencyIndicator({
  label,
  tone = "neutral",
  wrap
}) {
  return /*#__PURE__*/React.createElement(__ds_scope.StatusBadge, {
    label: label,
    tone: tone,
    srPrefix: "Urg\xEAncia",
    wrap: wrap
  });
}
Object.assign(__ds_scope, { UrgencyIndicator });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/UrgencyIndicator.jsx", error: String((e && e.message) || e) }); }

// components/data/DataTable.jsx
try { (() => {
/**
 * DataTable — a generic wrapper over a real <table> so every operational collection gets the
 * same column semantics, group headers and narrow-stacking behaviour.
 *
 * Deliberate non-features: no sorting UI, no column resizing, no row selection, no virtual
 * scrolling. None are needed by an approved journey, and adding them would be a UX change
 * without evidence.
 */
function cellClassName(column) {
  if (column.primary) return "ui-table__cell--primary";
  if (column.actions) return "ui-table__cell--actions";
  if (column.numeric) return "ui-table__cell--numeric";
  return "";
}
function Row({
  row,
  columns,
  rowKey
}) {
  return /*#__PURE__*/React.createElement("tr", null, columns.map(column => /*#__PURE__*/React.createElement("td", {
    key: `${rowKey(row)}:${column.key}`,
    className: cellClassName(column),
    "data-label": column.primary || column.actions ? undefined : column.header
  }, column.render(row))));
}
function DataTable({
  caption,
  columns,
  rows,
  groups,
  rowKey,
  density = "comfortable",
  stickyHeader
}) {
  const body = groups ? groups.map(group => /*#__PURE__*/React.createElement("tbody", {
    key: group.id
  }, /*#__PURE__*/React.createElement("tr", {
    className: "ui-table__group-header"
  }, /*#__PURE__*/React.createElement("th", {
    scope: "rowgroup",
    colSpan: columns.length
  }, group.label, /*#__PURE__*/React.createElement("span", {
    className: "ui-table__group-count"
  }, group.rows.length))), group.rows.map(row => /*#__PURE__*/React.createElement(Row, {
    key: rowKey(row),
    row: row,
    columns: columns,
    rowKey: rowKey
  })))) : [/*#__PURE__*/React.createElement("tbody", {
    key: "rows"
  }, (rows || []).map(row => /*#__PURE__*/React.createElement(Row, {
    key: rowKey(row),
    row: row,
    columns: columns,
    rowKey: rowKey
  })))];
  const className = ["ui-table", density === "compact" ? "ui-table--compact" : "", stickyHeader ? "ui-table--sticky" : ""].filter(Boolean).join(" ");
  return /*#__PURE__*/React.createElement("div", {
    className: "ui-table-scroll"
  }, /*#__PURE__*/React.createElement("table", {
    className: className
  }, /*#__PURE__*/React.createElement("caption", {
    className: "u-visually-hidden"
  }, caption), /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", null, columns.map(column => /*#__PURE__*/React.createElement("th", {
    key: column.key,
    scope: "col",
    className: cellClassName(column)
  }, column.actions ? /*#__PURE__*/React.createElement("span", {
    className: "u-visually-hidden"
  }, column.header) : column.header)))), body));
}

/** Secondary line under a primary cell's main value (issuer, document number, relative date). */
function CellSecondary({
  children
}) {
  return /*#__PURE__*/React.createElement("span", {
    className: "ui-table__secondary"
  }, children);
}
Object.assign(__ds_scope, { DataTable, CellSecondary });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/DataTable.jsx", error: String((e && e.message) || e) }); }

// components/feedback/AsyncFeedback.jsx
try { (() => {
const TONE = {
  PENDING: "neutral",
  PROCESSING: "info",
  COMPLETED: "success",
  FAILED: "critical",
  UNKNOWN: "warning"
};

/** AsyncFeedback — mutation outcome as a notice. UNKNOWN is rendered `warning`, never
 * `critical`: it is not a failure, it is an unconfirmed outcome. */
function AsyncFeedback({
  state,
  message
}) {
  const role = state === "FAILED" || state === "UNKNOWN" ? "alert" : "status";
  return /*#__PURE__*/React.createElement("div", {
    className: `ui-notice ui-notice--${TONE[state]}`,
    role: role,
    "aria-live": "polite"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ui-notice__body"
  }, message));
}
Object.assign(__ds_scope, { AsyncFeedback });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/AsyncFeedback.jsx", error: String((e && e.message) || e) }); }

// components/feedback/BackgroundRefreshIndicator.jsx
try { (() => {
/** BackgroundRefreshIndicator — data already on screen, quietly refreshing. Never replaces
 * visible content and never causes a layout jump. */
function BackgroundRefreshIndicator({
  label = "Atualizando…"
}) {
  return /*#__PURE__*/React.createElement("span", {
    className: "ui-refresh-indicator",
    role: "status",
    "aria-live": "polite"
  }, /*#__PURE__*/React.createElement("span", {
    className: "ui-refresh-indicator__dot",
    "aria-hidden": "true"
  }), label);
}
Object.assign(__ds_scope, { BackgroundRefreshIndicator });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/BackgroundRefreshIndicator.jsx", error: String((e && e.message) || e) }); }

// components/feedback/CollectionSkeleton.jsx
try { (() => {
/** CollectionSkeleton — only where the structure being waited on is genuinely known (a table
 * of rows). Reserving the rows' height also keeps the page from jumping when data lands. */
function CollectionSkeleton({
  rows = 6,
  label = "Carregando…"
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "ui-skeleton"
  }, /*#__PURE__*/React.createElement("span", {
    className: "u-visually-hidden",
    role: "status",
    "aria-live": "polite"
  }, label), /*#__PURE__*/React.createElement("div", {
    "aria-hidden": "true"
  }, Array.from({
    length: rows
  }, (_, index) => /*#__PURE__*/React.createElement("div", {
    className: "ui-skeleton__row",
    key: index
  }, /*#__PURE__*/React.createElement("span", {
    className: "ui-skeleton__bar ui-skeleton__bar--wide"
  }), /*#__PURE__*/React.createElement("span", {
    className: "ui-skeleton__bar ui-skeleton__bar--medium"
  }), /*#__PURE__*/React.createElement("span", {
    className: "ui-skeleton__bar ui-skeleton__bar--narrow"
  })))));
}
Object.assign(__ds_scope, { CollectionSkeleton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/CollectionSkeleton.jsx", error: String((e && e.message) || e) }); }

// components/feedback/EmptyState.jsx
try { (() => {
const DEFAULT_MESSAGE = {
  "true-empty": "Nada cadastrado ainda.",
  "filtered-empty": "Nenhum resultado para este filtro.",
  "not-ready": "Ainda não há nada aqui.",
  unavailable: "Não é possível carregar isto agora.",
  "permission-limited": "Você não tem acesso a este conteúdo."
};
const TITLE = {
  "true-empty": "Comece por aqui",
  "filtered-empty": "Nenhum resultado",
  unavailable: "Conteúdo indisponível",
  "permission-limited": "Acesso restrito"
};

/**
 * EmptyState — five structurally distinct kinds, so a caller never collapses "genuinely
 * nothing yet" into "your filter matched nothing". Only `true-empty` gets an inviting title,
 * because only `true-empty` is an invitation to create something.
 */
function EmptyState({
  kind,
  message,
  action
}) {
  const title = TITLE[kind];
  return /*#__PURE__*/React.createElement("div", {
    className: "ui-async-block",
    "data-empty-kind": kind
  }, title ? /*#__PURE__*/React.createElement("p", {
    className: "ui-async-block__title"
  }, title) : null, /*#__PURE__*/React.createElement("p", {
    className: "ui-async-block__message"
  }, message || DEFAULT_MESSAGE[kind]), action ? /*#__PURE__*/React.createElement("div", {
    className: "ui-async-block__actions"
  }, action) : null);
}
Object.assign(__ds_scope, { EmptyState });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/EmptyState.jsx", error: String((e && e.message) || e) }); }

// components/feedback/ErrorState.jsx
try { (() => {
/** ErrorState — a failed load, with its retry. Bordered in the critical tone so it is never
 * mistaken for "nothing here". */
function ErrorState({
  message,
  onRetry,
  retryLabel = "Tentar novamente"
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "ui-async-block ui-async-block--error",
    role: "alert"
  }, /*#__PURE__*/React.createElement("p", {
    className: "ui-async-block__title"
  }, "N\xE3o foi poss\xEDvel concluir esta a\xE7\xE3o"), /*#__PURE__*/React.createElement("p", {
    className: "ui-async-block__message"
  }, message), onRetry ? /*#__PURE__*/React.createElement("div", {
    className: "ui-async-block__actions"
  }, /*#__PURE__*/React.createElement(__ds_scope.Button, {
    variant: "secondary",
    onClick: onRetry
  }, retryLabel)) : null);
}
Object.assign(__ds_scope, { ErrorState });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/ErrorState.jsx", error: String((e && e.message) || e) }); }

// components/feedback/InitialLoading.jsx
try { (() => {
/** InitialLoading — first paint where the structure is not known in advance. Plain text, no
 * spinner: there is no spinner in this system. */
function InitialLoading({
  label = "Carregando…"
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "ui-inline-loading",
    role: "status",
    "aria-live": "polite"
  }, label);
}
Object.assign(__ds_scope, { InitialLoading });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/InitialLoading.jsx", error: String((e && e.message) || e) }); }

// components/forms/FormErrorSummary.jsx
try { (() => {
/**
 * FormErrorSummary — the result of a submit attempt, so role="alert" is correct: the user just
 * acted and needs to know the action did not happen. Field errors render as links that move
 * focus to the offending control; general problems are text only.
 */
function FormErrorSummary({
  errors = [],
  fieldErrors = []
}) {
  if (errors.length === 0 && fieldErrors.length === 0) return null;
  const onlyOneGeneralError = errors.length === 1 && fieldErrors.length === 0;
  return /*#__PURE__*/React.createElement("div", {
    className: "ui-error-summary",
    role: "alert"
  }, onlyOneGeneralError ? /*#__PURE__*/React.createElement("p", {
    className: "ui-error-summary__title"
  }, errors[0]) : /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("p", {
    className: "ui-error-summary__title"
  }, "Corrija os seguintes problemas:"), /*#__PURE__*/React.createElement("ul", {
    className: "ui-error-summary__list"
  }, fieldErrors.map(fieldError => /*#__PURE__*/React.createElement("li", {
    key: fieldError.fieldId
  }, /*#__PURE__*/React.createElement("a", {
    href: `#${fieldError.fieldId}`
  }, fieldError.label, ": ", fieldError.message))), errors.map((message, index) => /*#__PURE__*/React.createElement("li", {
    key: `general-${index}`
  }, message)))));
}
Object.assign(__ds_scope, { FormErrorSummary });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/FormErrorSummary.jsx", error: String((e && e.message) || e) }); }

// components/forms/TextField.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * TextField — a visible <label> with a real htmlFor/id association, never a placeholder
 * standing in for a label. Required/optional is stated in words, and the invalid state is
 * signalled by border weight + a left rule + the message, never by colour alone.
 */
function TextField({
  label,
  value,
  onChange,
  error,
  hint,
  required,
  maxLength,
  type = "text",
  autoComplete,
  multiline,
  id,
  width
}) {
  const errorId = `${id}-error`;
  const hintId = `${id}-hint`;
  const describedBy = [hint ? hintId : undefined, error ? errorId : undefined].filter(Boolean).join(" ") || undefined;
  const controlProps = {
    id,
    className: "ui-field__control",
    value,
    maxLength,
    required,
    "aria-invalid": error ? true : undefined,
    "aria-describedby": describedBy,
    onChange: event => onChange && onChange(event.target.value)
  };
  return /*#__PURE__*/React.createElement("div", {
    className: `ui-field${error ? " ui-field--invalid" : ""}`,
    "data-width": width
  }, /*#__PURE__*/React.createElement("label", {
    className: "ui-field__label",
    htmlFor: id
  }, label, " ", /*#__PURE__*/React.createElement("span", {
    className: "ui-field__requirement"
  }, required ? "(obrigatório)" : "(opcional)")), hint ? /*#__PURE__*/React.createElement("p", {
    className: "ui-field__hint",
    id: hintId
  }, hint) : null, multiline ? /*#__PURE__*/React.createElement("textarea", controlProps) : /*#__PURE__*/React.createElement("input", _extends({}, controlProps, {
    type: type,
    autoComplete: autoComplete
  })), error ? /*#__PURE__*/React.createElement("p", {
    className: "ui-field__error",
    id: errorId,
    role: "alert"
  }, error) : null);
}
Object.assign(__ds_scope, { TextField });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/TextField.jsx", error: String((e && e.message) || e) }); }

// components/layout/DetailList.jsx
try { (() => {
/**
 * DetailList — one record's attributes as a <dl>. Never a table: a table implies comparable
 * rows and there is exactly one record here. Empty values are dropped, not rendered as "—".
 */
function DetailList({
  fields
}) {
  const present = fields.filter(field => Boolean(field.value));
  if (present.length === 0) return null;
  return /*#__PURE__*/React.createElement("dl", {
    className: "ui-detail-list"
  }, present.map(field => /*#__PURE__*/React.createElement("div", {
    key: field.label
  }, /*#__PURE__*/React.createElement("dt", null, field.label), /*#__PURE__*/React.createElement("dd", null, field.value))));
}
Object.assign(__ds_scope, { DetailList });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/layout/DetailList.jsx", error: String((e && e.message) || e) }); }

// components/layout/FilterGroup.jsx
try { (() => {
/**
 * FilterGroup — segmented status filter. Real <button>s driven by aria-pressed: these are not
 * pages (so never aria-current) and not tabs (no tabpanel, no tab keyboard model).
 */
function FilterGroup({
  label,
  options,
  value,
  onChange
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "ui-filter",
    role: "group",
    "aria-label": label
  }, options.map(option => /*#__PURE__*/React.createElement("button", {
    key: option.value,
    type: "button",
    className: "ui-filter__option",
    "aria-pressed": option.value === value,
    onClick: () => onChange && onChange(option.value)
  }, option.label, typeof option.count === "number" ? /*#__PURE__*/React.createElement("span", {
    className: "ui-filter__count"
  }, option.count) : null)));
}
Object.assign(__ds_scope, { FilterGroup });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/layout/FilterGroup.jsx", error: String((e && e.message) || e) }); }

// components/layout/PageHeader.jsx
try { (() => {
/** PageHeader — owns what a page title looks like, so no screen re-invents it. */
function PageHeader({
  title,
  description,
  above,
  actions,
  badges
}) {
  return /*#__PURE__*/React.createElement("header", {
    className: "ui-page-header"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ui-page-header__text"
  }, above ? /*#__PURE__*/React.createElement("div", {
    className: "ui-page-header__back"
  }, above) : null, /*#__PURE__*/React.createElement("h1", null, title), badges ? /*#__PURE__*/React.createElement("div", {
    className: "ui-page-header__badges"
  }, badges) : null, description ? /*#__PURE__*/React.createElement("p", {
    className: "ui-page-header__description"
  }, description) : null), actions ? /*#__PURE__*/React.createElement("div", {
    className: "ui-page-header__actions"
  }, actions) : null);
}
Object.assign(__ds_scope, { PageHeader });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/layout/PageHeader.jsx", error: String((e && e.message) || e) }); }

// components/layout/Panel.jsx
try { (() => {
/**
 * Panel — the system's ONLY grouping container: a light surface with a hairline border and no
 * shadow. Never nested inside another panel. `header`/`footer` are the refinement that lets a
 * collection's toolbar and its "ver todos" link belong to the panel instead of floating.
 */
function Panel({
  children,
  padded,
  header,
  footer
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: padded ? "ui-panel ui-panel--padded" : "ui-panel"
  }, header ? /*#__PURE__*/React.createElement("div", {
    className: "ui-panel__header"
  }, header) : null, children, footer ? /*#__PURE__*/React.createElement("div", {
    className: "ui-panel__footer"
  }, footer) : null);
}
Object.assign(__ds_scope, { Panel });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/layout/Panel.jsx", error: String((e && e.message) || e) }); }

// components/layout/Section.jsx
try { (() => {
/** Section — an <h2>-titled region wired to its heading via aria-labelledby. */
function Section({
  heading,
  headingId,
  annotation,
  description,
  children
}) {
  return /*#__PURE__*/React.createElement("section", {
    className: "ui-section",
    "aria-labelledby": headingId
  }, /*#__PURE__*/React.createElement("h2", {
    id: headingId,
    className: "ui-section__heading"
  }, heading, annotation ? /*#__PURE__*/React.createElement(React.Fragment, null, " ", annotation) : null), description ? /*#__PURE__*/React.createElement("p", {
    className: "ui-section__description"
  }, description) : null, children);
}
Object.assign(__ds_scope, { Section });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/layout/Section.jsx", error: String((e && e.message) || e) }); }

// components/layout/Toolbar.jsx
try { (() => {
/** Toolbar — the filter/refresh row above a collection. */
function Toolbar({
  children
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "ui-toolbar"
  }, children);
}

/** Pushes everything after it to the right. */
function ToolbarSpacer() {
  return /*#__PURE__*/React.createElement("span", {
    className: "ui-toolbar__spacer"
  });
}
Object.assign(__ds_scope, { Toolbar, ToolbarSpacer });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/layout/Toolbar.jsx", error: String((e && e.message) || e) }); }

// components/shell/AppShell.jsx
try { (() => {
/**
 * AppShell — nav landmark + main content region + skip link. The nav mirrors the dual-anchor
 * IA (Vencimentos and Fornecedor/Subject as two coexisting anchors, no single hierarchy).
 * There is no logo file in the product: the brand is a plain type wordmark.
 */
function AppShell({
  wordmark = "Expiration Tracker",
  items = [],
  footer,
  children
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "app-shell"
  }, /*#__PURE__*/React.createElement("a", {
    href: "#surface-content",
    className: "skip-link"
  }, "Pular para o conte\xFAdo"), /*#__PURE__*/React.createElement("nav", {
    className: "app-shell__nav",
    "aria-label": "Navega\xE7\xE3o principal"
  }, /*#__PURE__*/React.createElement("span", {
    className: "app-shell__wordmark"
  }, wordmark), items.map(item => /*#__PURE__*/React.createElement("a", {
    key: item.label,
    href: item.href || "#",
    className: "app-shell__link",
    "aria-current": item.current ? "page" : undefined,
    onClick: item.onClick
  }, item.label)), /*#__PURE__*/React.createElement("span", {
    className: "app-shell__nav-spacer"
  }), footer), /*#__PURE__*/React.createElement("main", {
    className: "app-shell__main",
    id: "surface-content",
    tabIndex: -1
  }, children));
}
Object.assign(__ds_scope, { AppShell });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/shell/AppShell.jsx", error: String((e && e.message) || e) }); }

// ui_kits/webapp/CollectionScreens-v2.jsx
try { (() => {
const {
  Button,
  ButtonLink,
  Chip,
  Tag,
  Person,
  PageHeader,
  Panel,
  FilterGroup,
  DataTable,
  RefreshIndicator,
  EmptyState
} = window;
const {
  byStatus,
  sortByDueDateAscending,
  presentUrgency,
  formatAbsoluteDate,
  formatRelativeDueContext,
  STATUS_LABEL
} = window;
function DueCell({
  item
}) {
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "v2-table__date"
  }, formatAbsoluteDate(item.dueDate)), /*#__PURE__*/React.createElement("div", {
    className: "v2-table__secondary"
  }, formatRelativeDueContext(item.dueDate)));
}
function NameCell({
  item,
  onOpen
}) {
  const secondary = [item.issuer, item.number ? "nº " + item.number : null].filter(Boolean).join(" · ");
  return /*#__PURE__*/React.createElement("div", {
    className: "v2-table__name"
  }, /*#__PURE__*/React.createElement("a", {
    href: "#",
    onClick: e => {
      e.preventDefault();
      onOpen(item);
    }
  }, item.name), secondary ? /*#__PURE__*/React.createElement("span", {
    className: "v2-table__secondary"
  }, secondary) : null);
}
function OverviewScreen({
  go
}) {
  const items = sortByDueDateAscending(byStatus("ACTIVE"));
  const upcoming = items.slice(0, 7);
  const overdue = items.filter(i => presentUrgency(i).group === "overdue");
  const soon = items.filter(i => presentUrgency(i).group === "soon");
  const columns = [{
    key: "name",
    header: "Vencimento",
    render: i => /*#__PURE__*/React.createElement(NameCell, {
      item: i,
      onOpen: x => go("detail", {
        itemId: x.itemId
      })
    })
  }, {
    key: "cat",
    header: "Categoria",
    render: i => /*#__PURE__*/React.createElement(Tag, {
      text: i.category
    })
  }, {
    key: "due",
    header: "Data",
    render: i => /*#__PURE__*/React.createElement(DueCell, {
      item: i
    })
  }, {
    key: "urgency",
    header: "Urgência",
    render: i => {
      const u = presentUrgency(i);
      return /*#__PURE__*/React.createElement(Chip, {
        label: u.label,
        tone: u.tone
      });
    }
  }, {
    key: "actions",
    header: "",
    actions: true,
    render: i => /*#__PURE__*/React.createElement(Button, {
      variant: "tertiary",
      size: "sm",
      icon: "RefreshCw",
      onClick: () => go("renew", {
        itemId: i.itemId
      })
    }, "Renovar")
  }];
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(PageHeader, {
    title: "Boa tarde, Marcelo",
    description: "Aqui est\xE1 o que precisa da sua aten\xE7\xE3o hoje, do mais urgente para o menos urgente.",
    actions: /*#__PURE__*/React.createElement(Button, {
      variant: "primary",
      icon: "Plus",
      onClick: () => go("create")
    }, "Novo vencimento")
  }), /*#__PURE__*/React.createElement("div", {
    className: "v2-attention"
  }, /*#__PURE__*/React.createElement("a", {
    className: "v2-stat",
    href: "#",
    onClick: e => {
      e.preventDefault();
      go("items", {
        focus: "overdue"
      });
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "v2-stat__icon v2-stat__icon--critical"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "CircleAlert"
  })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "v2-stat__count"
  }, overdue.length), /*#__PURE__*/React.createElement("div", {
    className: "v2-stat__label"
  }, "vencidos"))), /*#__PURE__*/React.createElement("a", {
    className: "v2-stat",
    href: "#",
    onClick: e => {
      e.preventDefault();
      go("items", {
        focus: "soon"
      });
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "v2-stat__icon v2-stat__icon--warning"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "Clock"
  })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "v2-stat__count"
  }, soon.length), /*#__PURE__*/React.createElement("div", {
    className: "v2-stat__label"
  }, "vencem em 7 dias"))), /*#__PURE__*/React.createElement("a", {
    className: "v2-stat",
    href: "#",
    onClick: e => {
      e.preventDefault();
      go("items");
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "v2-stat__icon v2-stat__icon--neutral"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "ListChecks"
  })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "v2-stat__count"
  }, items.length), /*#__PURE__*/React.createElement("div", {
    className: "v2-stat__label"
  }, "em acompanhamento")))), /*#__PURE__*/React.createElement(Panel, {
    header: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("h2", {
      className: "v2-panel__title"
    }, "Precisa de aten\xE7\xE3o primeiro"), /*#__PURE__*/React.createElement("span", {
      className: "v2-panel__count"
    }, "7 de ", items.length, " vencimentos ativos")),
    footer: /*#__PURE__*/React.createElement("a", {
      href: "#",
      onClick: e => {
        e.preventDefault();
        go("items");
      }
    }, "Ver todos os vencimentos", /*#__PURE__*/React.createElement(Icon, {
      name: "ArrowRight",
      size: 13
    }))
  }, /*#__PURE__*/React.createElement(DataTable, {
    caption: "Vencimentos ativos",
    columns: columns,
    rows: upcoming,
    rowKey: i => i.itemId
  })));
}
const STATUS_TABS = [{
  value: "ACTIVE",
  label: "Ativos"
}, {
  value: "ARCHIVED",
  label: "Arquivados"
}, {
  value: "RENEWED",
  label: "Renovados"
}];
function CollectionScreen({
  go
}) {
  const [status, setStatus] = React.useState("ACTIVE");
  const [refreshing, setRefreshing] = React.useState(false);
  function refresh() {
    setRefreshing(true);
    window.setTimeout(() => setRefreshing(false), 1200);
  }
  const entries = sortByDueDateAscending(byStatus(status)).map(item => ({
    item,
    urgency: presentUrgency(item)
  }));
  const columns = [{
    key: "name",
    header: "Vencimento",
    render: ({
      item
    }) => /*#__PURE__*/React.createElement(NameCell, {
      item: item,
      onOpen: x => go("detail", {
        itemId: x.itemId
      })
    })
  }, {
    key: "cat",
    header: "Categoria",
    render: ({
      item
    }) => /*#__PURE__*/React.createElement(Tag, {
      text: item.category
    })
  }, {
    key: "due",
    header: "Data de vencimento",
    render: ({
      item
    }) => /*#__PURE__*/React.createElement(DueCell, {
      item: item
    })
  }, {
    key: "resp",
    header: "Responsável",
    render: ({
      item
    }) => /*#__PURE__*/React.createElement(Person, {
      name: item.assigneeUserId || "—"
    })
  }, {
    key: "urgency",
    header: "Urgência",
    render: ({
      urgency
    }) => /*#__PURE__*/React.createElement(Chip, {
      label: urgency.label,
      tone: urgency.tone
    })
  }, {
    key: "actions",
    header: "",
    actions: true,
    render: ({
      item
    }) => item.status === "ACTIVE" ? /*#__PURE__*/React.createElement(Button, {
      variant: "secondary",
      size: "sm",
      icon: "RefreshCw",
      onClick: () => go("renew", {
        itemId: item.itemId
      })
    }, "Renovar") : null
  }];
  const groups = status === "ACTIVE" ? [{
    id: "overdue",
    label: "Vencidos",
    rows: entries.filter(e => e.urgency.group === "overdue")
  }, {
    id: "soon",
    label: "Vence em breve",
    rows: entries.filter(e => e.urgency.group === "soon")
  }, {
    id: "later",
    label: "Demais ativos",
    rows: entries.filter(e => e.urgency.group === "later")
  }].filter(g => g.rows.length > 0) : undefined;
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(PageHeader, {
    title: "Vencimentos",
    description: "Tudo o que est\xE1 sendo acompanhado.",
    actions: /*#__PURE__*/React.createElement(Button, {
      variant: "primary",
      icon: "Plus",
      onClick: () => go("create")
    }, "Novo vencimento")
  }), /*#__PURE__*/React.createElement("div", {
    className: "v2-topbar"
  }, /*#__PURE__*/React.createElement("div", {
    className: "v2-search"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "Search"
  }), /*#__PURE__*/React.createElement("input", {
    placeholder: "Buscar por nome, emissor ou n\xFAmero\u2026"
  }))), /*#__PURE__*/React.createElement(Panel, {
    header: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(FilterGroup, {
      label: "Filtrar por status",
      options: STATUS_TABS,
      value: status,
      onChange: setStatus
    }), /*#__PURE__*/React.createElement("span", {
      className: "v2-toolbar-spacer"
    }), refreshing ? /*#__PURE__*/React.createElement(RefreshIndicator, null) : /*#__PURE__*/React.createElement("span", {
      className: "v2-panel__count"
    }, entries.length, " registros"), /*#__PURE__*/React.createElement(Button, {
      variant: "secondary",
      size: "sm",
      icon: "RefreshCw",
      onClick: refresh
    }, "Atualizar")),
    footer: status === "ACTIVE" ? /*#__PURE__*/React.createElement("span", null, "Agrupado por urg\xEAncia, do mais cr\xEDtico para o menos urgente.") : /*#__PURE__*/React.createElement("span", null, entries.length, " vencimentos neste status.")
  }, entries.length === 0 ? /*#__PURE__*/React.createElement(EmptyState, {
    icon: "Filter",
    title: "Nenhum resultado",
    message: "Nenhum vencimento neste status."
  }) : /*#__PURE__*/React.createElement(DataTable, {
    caption: "Vencimentos — " + status,
    columns: columns,
    groups: groups,
    rows: groups ? undefined : entries,
    rowKey: e => e.item.itemId,
    density: "compact"
  })));
}
Object.assign(window, {
  OverviewScreen,
  CollectionScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/webapp/CollectionScreens-v2.jsx", error: String((e && e.message) || e) }); }

// ui_kits/webapp/CollectionScreens.jsx
try { (() => {
/* Visão geral + Vencimentos — the two collection surfaces. */
const {
  Button,
  ButtonLink,
  Badge,
  PageHeader,
  Panel,
  FilterGroup,
  DataTable,
  CellSecondary,
  BackgroundRefreshIndicator,
  EmptyState
} = window;
const {
  byStatus,
  sortByDueDateAscending,
  presentUrgency,
  formatAbsoluteDate,
  formatRelativeDueContext,
  STATUS_LABEL
} = window;

/** Urgency renders as a pill only when it asks for attention; "Sem urgência"/"Não se aplica"
 *  render inline. The label and the shape marker are unchanged either way. */
function Urgency({
  urgency
}) {
  return /*#__PURE__*/React.createElement(Badge, {
    label: urgency.label,
    tone: urgency.tone,
    srPrefix: "Urg\xEAncia",
    inline: urgency.tone === "neutral"
  });
}
function DueCell({
  item
}) {
  return /*#__PURE__*/React.createElement(React.Fragment, null, formatAbsoluteDate(item.dueDate), /*#__PURE__*/React.createElement(CellSecondary, null, formatRelativeDueContext(item.dueDate)));
}
function NameCell({
  item,
  onOpen
}) {
  const secondary = [item.issuer, item.number ? "nº " + item.number : null].filter(Boolean).join(" · ");
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("a", {
    href: "#",
    onClick: e => {
      e.preventDefault();
      onOpen(item);
    }
  }, item.name), secondary ? /*#__PURE__*/React.createElement(CellSecondary, null, secondary) : null);
}
function OverviewScreen({
  go
}) {
  const items = sortByDueDateAscending(byStatus("ACTIVE"));
  const upcoming = items.slice(0, 7);
  const overdue = items.filter(i => presentUrgency(i).group === "overdue");
  const soon = items.filter(i => presentUrgency(i).group === "soon");
  const columns = [{
    key: "name",
    header: "Vencimento",
    primary: true,
    render: i => /*#__PURE__*/React.createElement(NameCell, {
      item: i,
      onOpen: x => go("detail", {
        itemId: x.itemId
      })
    })
  }, {
    key: "due",
    header: "Data",
    numeric: true,
    render: i => /*#__PURE__*/React.createElement(DueCell, {
      item: i
    })
  }, {
    key: "urgency",
    header: "Urgência",
    render: i => /*#__PURE__*/React.createElement(Urgency, {
      urgency: presentUrgency(i)
    })
  }, {
    key: "actions",
    header: "Ações",
    actions: true,
    render: i => /*#__PURE__*/React.createElement(Button, {
      variant: "tertiary",
      size: "sm",
      onClick: () => go("renew", {
        itemId: i.itemId
      })
    }, "Renovar")
  }];
  return /*#__PURE__*/React.createElement("div", {
    className: "ui-page"
  }, /*#__PURE__*/React.createElement(PageHeader, {
    title: "Vis\xE3o geral",
    description: "Seus vencimentos ativos, do mais urgente para o menos urgente.",
    actions: /*#__PURE__*/React.createElement(Button, {
      variant: "primary",
      onClick: () => go("create")
    }, "Novo vencimento")
  }), /*#__PURE__*/React.createElement("ul", {
    className: "ui-attention"
  }, /*#__PURE__*/React.createElement("li", null, /*#__PURE__*/React.createElement("a", {
    className: "ui-attention__item",
    "data-tone": "critical",
    href: "#",
    onClick: e => {
      e.preventDefault();
      go("items", {
        focus: "overdue"
      });
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "ui-attention__count"
  }, overdue.length), /*#__PURE__*/React.createElement("span", {
    className: "ui-attention__label"
  }, "vencidos"))), /*#__PURE__*/React.createElement("li", null, /*#__PURE__*/React.createElement("a", {
    className: "ui-attention__item",
    "data-tone": "warning",
    href: "#",
    onClick: e => {
      e.preventDefault();
      go("items", {
        focus: "soon"
      });
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "ui-attention__count"
  }, soon.length), /*#__PURE__*/React.createElement("span", {
    className: "ui-attention__label"
  }, "vencem nos pr\xF3ximos 7 dias"))), /*#__PURE__*/React.createElement("li", null, /*#__PURE__*/React.createElement("a", {
    className: "ui-attention__item",
    href: "#",
    onClick: e => {
      e.preventDefault();
      go("items");
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "ui-attention__count"
  }, items.length), /*#__PURE__*/React.createElement("span", {
    className: "ui-attention__label"
  }, "em acompanhamento")))), /*#__PURE__*/React.createElement(Panel, {
    header: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("h2", {
      className: "ui-panel__title"
    }, "Precisa de aten\xE7\xE3o primeiro"), /*#__PURE__*/React.createElement("span", {
      className: "ui-panel__count"
    }, "7 de ", items.length, " vencimentos ativos")),
    footer: /*#__PURE__*/React.createElement("a", {
      href: "#",
      onClick: e => {
        e.preventDefault();
        go("items");
      }
    }, "Ver todos os vencimentos")
  }, /*#__PURE__*/React.createElement(DataTable, {
    caption: "Vencimentos ativos, do mais urgente para o menos urgente",
    columns: columns,
    rows: upcoming,
    rowKey: i => i.itemId
  })));
}
const STATUS_TABS = [{
  value: "ACTIVE",
  label: "Ativos"
}, {
  value: "ARCHIVED",
  label: "Arquivados"
}, {
  value: "RENEWED",
  label: "Renovados"
}];
function CollectionScreen({
  go
}) {
  const [status, setStatus] = React.useState("ACTIVE");
  const [refreshing, setRefreshing] = React.useState(false);
  function refresh() {
    setRefreshing(true);
    window.setTimeout(() => setRefreshing(false), 1400);
  }
  const entries = sortByDueDateAscending(byStatus(status)).map(item => ({
    item,
    urgency: presentUrgency(item)
  }));
  const columns = [{
    key: "name",
    header: "Vencimento",
    primary: true,
    render: ({
      item
    }) => /*#__PURE__*/React.createElement(NameCell, {
      item: item,
      onOpen: x => go("detail", {
        itemId: x.itemId
      })
    })
  }, {
    key: "category",
    header: "Categoria",
    render: ({
      item
    }) => /*#__PURE__*/React.createElement("span", {
      className: "u-text-secondary"
    }, item.category)
  }, {
    key: "due",
    header: "Data de vencimento",
    numeric: true,
    render: ({
      item
    }) => /*#__PURE__*/React.createElement(DueCell, {
      item: item
    })
  }, {
    key: "urgency",
    header: "Urgência",
    render: ({
      urgency
    }) => /*#__PURE__*/React.createElement(Urgency, {
      urgency: urgency
    })
  }, {
    key: "status",
    header: "Situação",
    render: ({
      item
    }) => /*#__PURE__*/React.createElement(Badge, {
      label: STATUS_LABEL[item.status],
      tone: "neutral",
      srPrefix: "Situa\xE7\xE3o",
      inline: true
    })
  }, {
    key: "actions",
    header: "Ações",
    actions: true,
    render: ({
      item
    }) => item.status === "ACTIVE" ? /*#__PURE__*/React.createElement(Button, {
      variant: "secondary",
      size: "sm",
      onClick: () => go("renew", {
        itemId: item.itemId
      })
    }, "Renovar") : null
  }];
  const groups = status === "ACTIVE" ? [{
    id: "overdue",
    label: "Vencidos",
    rows: entries.filter(e => e.urgency.group === "overdue")
  }, {
    id: "soon",
    label: "Vence em breve",
    rows: entries.filter(e => e.urgency.group === "soon")
  }, {
    id: "later",
    label: "Demais ativos",
    rows: entries.filter(e => e.urgency.group === "later")
  }].filter(g => g.rows.length > 0) : undefined;
  const header = /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(FilterGroup, {
    label: "Filtrar por status",
    options: STATUS_TABS,
    value: status,
    onChange: setStatus
  }), /*#__PURE__*/React.createElement("span", {
    className: "ui-toolbar__spacer"
  }), refreshing ? /*#__PURE__*/React.createElement(BackgroundRefreshIndicator, null) : /*#__PURE__*/React.createElement("span", {
    className: "ui-panel__count"
  }, entries.length, " registros"), /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    size: "sm",
    onClick: refresh
  }, "Atualizar"));
  return /*#__PURE__*/React.createElement("div", {
    className: "ui-page"
  }, /*#__PURE__*/React.createElement(PageHeader, {
    title: "Vencimentos",
    description: "Tudo o que est\xE1 sendo acompanhado, do mais urgente para o menos urgente.",
    actions: /*#__PURE__*/React.createElement(Button, {
      variant: "primary",
      onClick: () => go("create")
    }, "Novo vencimento")
  }), /*#__PURE__*/React.createElement(Panel, {
    header: header,
    footer: status === "ACTIVE" ? /*#__PURE__*/React.createElement("span", null, "Agrupado por urg\xEAncia. Dentro de cada grupo, do mais urgente para o menos urgente.") : /*#__PURE__*/React.createElement("span", null, entries.length, " vencimentos neste status.")
  }, entries.length === 0 ? /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "24px"
    }
  }, /*#__PURE__*/React.createElement(EmptyState, {
    kind: "filtered-empty",
    message: "Nenhum vencimento neste status."
  })) : /*#__PURE__*/React.createElement(DataTable, {
    caption: "Vencimentos — " + (STATUS_TABS.find(t => t.value === status) || {}).label,
    columns: columns,
    groups: groups,
    rows: groups ? undefined : entries,
    rowKey: e => e.item.itemId,
    density: "compact"
  })));
}
Object.assign(window, {
  OverviewScreen,
  CollectionScreen,
  Urgency,
  DueCell
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/webapp/CollectionScreens.jsx", error: String((e && e.message) || e) }); }

// ui_kits/webapp/DocumentAndAlertScreens-v2.jsx
try { (() => {
const {
  Button,
  Chip,
  PageHeader,
  BackLink,
  Panel,
  TextField,
  EmptyState
} = window;
function findItem(itemId) {
  return window.byStatus("ACTIVE").concat(window.byStatus("ARCHIVED"), window.byStatus("RENEWED")).find(i => i.itemId === itemId);
}
const FAKE_DOCS = {
  "i-04": [{
    name: "licenca-operacao-2026.pdf",
    size: "2.1 MB",
    uploadedAt: "12/03/2026",
    status: "CLEAN"
  }]
};
function DocumentContextScreen({
  go,
  params
}) {
  const item = findItem(params.itemId) || window.ITEMS[0];
  const docs = FAKE_DOCS[item.itemId] || [];
  const [uploading, setUploading] = React.useState(false);
  function simulateUpload() {
    setUploading(true);
    window.setTimeout(() => setUploading(false), 1400);
  }
  return /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 760
    }
  }, /*#__PURE__*/React.createElement(PageHeader, {
    above: /*#__PURE__*/React.createElement(BackLink, {
      onClick: e => {
        e.preventDefault();
        go("detail", {
          itemId: item.itemId
        });
      }
    }, "Voltar para ", item.name),
    title: "Documentos",
    description: item.name
  }), /*#__PURE__*/React.createElement(window.InlineNotice, {
    tone: "info",
    icon: "ShieldCheck"
  }, /*#__PURE__*/React.createElement("p", null, "Todo arquivo passa por verifica\xE7\xE3o de seguran\xE7a antes de ficar dispon\xEDvel. Isso confirma que o arquivo \xE9 seguro \u2014 n\xE3o que o conte\xFAdo est\xE1 correto.")), /*#__PURE__*/React.createElement(Panel, {
    padded: true
  }, /*#__PURE__*/React.createElement("h2", {
    className: "v2-panel__title",
    style: {
      marginBottom: 14
    }
  }, "Arquivo atual"), docs.length === 0 ? /*#__PURE__*/React.createElement(EmptyState, {
    icon: "FileX",
    title: "Nenhum documento anexado",
    message: "Envie o arquivo que comprova este vencimento.",
    action: /*#__PURE__*/React.createElement(Button, {
      variant: "primary",
      icon: "Upload",
      onClick: simulateUpload,
      pending: uploading
    }, uploading ? "Enviando…" : "Enviar documento")
  }) : /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 10
    }
  }, docs.map(d => /*#__PURE__*/React.createElement("div", {
    key: d.name,
    style: {
      display: "flex",
      alignItems: "center",
      gap: 14,
      padding: "14px 16px",
      border: "1px solid var(--v2-ink-100)",
      borderRadius: "var(--v2-radius-md)"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 40,
      height: 40,
      borderRadius: 10,
      background: "var(--v2-accent-50)",
      color: "var(--v2-accent-700)",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      flex: "none"
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "FileText"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 700,
      fontSize: 13.5
    }
  }, d.name), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      color: "var(--v2-ink-500)"
    }
  }, d.size, " \xB7 enviado em ", d.uploadedAt)), /*#__PURE__*/React.createElement(Chip, {
    label: "Verificado",
    tone: "success",
    icon: "ShieldCheck"
  }), /*#__PURE__*/React.createElement(Button, {
    variant: "tertiary",
    size: "sm",
    icon: "Download"
  }, "Baixar"))), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    icon: "Upload",
    onClick: simulateUpload,
    pending: uploading
  }, uploading ? "Enviando…" : "Substituir arquivo")))));
}
const CHANNEL_LABEL = {
  EMAIL: "E-mail"
};
function AlertConfigurationScreen({
  go,
  params
}) {
  const item = findItem(params.itemId) || window.ITEMS[0];
  const [offset, setOffset] = React.useState("7");
  const [channel, setChannel] = React.useState("EMAIL");
  const [saved, setSaved] = React.useState(true);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 640
    }
  }, /*#__PURE__*/React.createElement(PageHeader, {
    above: /*#__PURE__*/React.createElement(BackLink, {
      onClick: e => {
        e.preventDefault();
        go("detail", {
          itemId: item.itemId
        });
      }
    }, "Voltar para ", item.name),
    title: "Configura\xE7\xE3o de alerta"
  }), /*#__PURE__*/React.createElement(Panel, {
    padded: true
  }, /*#__PURE__*/React.createElement("div", {
    className: "v2-field"
  }, /*#__PURE__*/React.createElement("label", {
    className: "v2-field__label"
  }, "Avisar com quantos dias de anteced\xEAncia"), /*#__PURE__*/React.createElement("select", {
    className: "v2-field__control",
    style: {
      maxWidth: 220
    },
    value: offset,
    onChange: e => {
      setOffset(e.target.value);
      setSaved(false);
    }
  }, /*#__PURE__*/React.createElement("option", {
    value: "1"
  }, "1 dia antes"), /*#__PURE__*/React.createElement("option", {
    value: "3"
  }, "3 dias antes"), /*#__PURE__*/React.createElement("option", {
    value: "7"
  }, "7 dias antes"), /*#__PURE__*/React.createElement("option", {
    value: "15"
  }, "15 dias antes"), /*#__PURE__*/React.createElement("option", {
    value: "30"
  }, "30 dias antes"))), /*#__PURE__*/React.createElement("div", {
    className: "v2-field"
  }, /*#__PURE__*/React.createElement("label", {
    className: "v2-field__label"
  }, "Canal"), /*#__PURE__*/React.createElement("select", {
    className: "v2-field__control",
    style: {
      maxWidth: 220
    },
    value: channel,
    onChange: e => {
      setChannel(e.target.value);
      setSaved(false);
    }
  }, /*#__PURE__*/React.createElement("option", {
    value: "EMAIL"
  }, "E-mail")), /*#__PURE__*/React.createElement("p", {
    className: "v2-field__hint",
    style: {
      marginTop: 8
    }
  }, "WhatsApp e SMS ainda n\xE3o est\xE3o dispon\xEDveis nesta conta.")), /*#__PURE__*/React.createElement("div", {
    className: "v2-form-actions"
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    icon: "Check",
    onClick: () => setSaved(true),
    disabled: saved
  }, saved ? "Salvo" : "Salvar política"))), /*#__PURE__*/React.createElement(window.InlineNotice, {
    tone: "warning",
    icon: "Info"
  }, /*#__PURE__*/React.createElement("p", null, "Pol\xEDtica salva confirma a prefer\xEAncia \u2014 n\xE3o garante que o aviso ser\xE1 entregue. Falhas de entrega, se ocorrerem, n\xE3o s\xE3o vis\xEDveis nesta tela hoje.")));
}
Object.assign(window, {
  DocumentContextScreen,
  AlertConfigurationScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/webapp/DocumentAndAlertScreens-v2.jsx", error: String((e && e.message) || e) }); }

// ui_kits/webapp/GuestScreen-v2.jsx
try { (() => {
/* Layout totalmente separado — sem nav do produto, sem branding interno. */
function GuestSubmissionScreen() {
  const [file, setFile] = React.useState(null);
  const [stage, setStage] = React.useState("initial");
  function submit() {
    setStage("uploading");
    window.setTimeout(() => setStage("submitted"), 1200);
  }
  return /*#__PURE__*/React.createElement("div", {
    className: "v2",
    style: {
      minHeight: "100vh",
      background: "linear-gradient(180deg,#faf9ff,#f3f1fb)",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      padding: 24
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: "100%",
      maxWidth: 480
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: "center",
      marginBottom: 24
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      width: 48,
      height: 48,
      borderRadius: 14,
      background: "linear-gradient(155deg,var(--v2-accent-500),var(--v2-accent-700))",
      alignItems: "center",
      justifyContent: "center",
      color: "#fff",
      fontWeight: 800,
      marginBottom: 12
    }
  }, "ET"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13,
      color: "var(--v2-ink-500)",
      fontWeight: 600
    }
  }, "Solicita\xE7\xE3o de documento")), /*#__PURE__*/React.createElement("div", {
    className: "v2-panel",
    style: {
      padding: 28
    }
  }, stage === "submitted" ? /*#__PURE__*/React.createElement(window.EmptyState, {
    icon: "CircleCheck",
    title: "Documento enviado",
    message: "Recebemos seu arquivo. A empresa solicitante ser\xE1 notificada."
  }) : /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("h1", {
    style: {
      margin: "0 0 6px",
      fontSize: 20,
      fontWeight: 800
    }
  }, "Comprovante de regularidade do im\xF3vel (IPTU)"), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: "0 0 20px",
      fontSize: 13.5,
      color: "var(--v2-ink-600)"
    }
  }, "Envie o documento solicitado. Prazo: ", /*#__PURE__*/React.createElement("strong", null, "24/08/2026"), "."), /*#__PURE__*/React.createElement("div", {
    style: {
      border: "2px dashed var(--v2-ink-200)",
      borderRadius: 14,
      padding: "32px 20px",
      textAlign: "center",
      marginBottom: 18
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "UploadCloud",
    size: 28,
    className: ""
  }), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: "10px 0 14px",
      fontSize: 13,
      color: "var(--v2-ink-500)"
    }
  }, file ? file : "PDF, JPG ou PNG até 10 MB"), /*#__PURE__*/React.createElement(window.Button, {
    variant: "secondary",
    size: "sm",
    icon: "Paperclip",
    onClick: () => setFile("iptu-2026.pdf")
  }, "Escolher arquivo")), /*#__PURE__*/React.createElement(window.Button, {
    variant: "primary",
    icon: stage === "uploading" ? undefined : "Send",
    pending: stage === "uploading",
    disabled: !file,
    onClick: submit,
    style: {
      width: "100%"
    }
  }, stage === "uploading" ? "Enviando…" : "Enviar documento"), /*#__PURE__*/React.createElement("p", {
    style: {
      marginTop: 16,
      fontSize: 11.5,
      color: "var(--v2-ink-400)",
      textAlign: "center"
    }
  }, "Seu arquivo passa por verifica\xE7\xE3o de seguran\xE7a antes de ser disponibilizado ao solicitante.")))));
}
window.GuestSubmissionScreen = GuestSubmissionScreen;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/webapp/GuestScreen-v2.jsx", error: String((e && e.message) || e) }); }

// ui_kits/webapp/RecordScreens-v2.jsx
try { (() => {
const {
  Button,
  Chip,
  Tag,
  Person,
  InlineNotice,
  PageHeader,
  BackLink,
  Panel,
  TextField,
  FormErrorSummary
} = window;
const {
  byStatus,
  presentUrgency,
  formatAbsoluteDate,
  formatRelativeDueContext,
  STATUS_LABEL
} = window;
function findItem(itemId) {
  return byStatus("ACTIVE").concat(byStatus("ARCHIVED"), byStatus("RENEWED")).find(i => i.itemId === itemId);
}
function HeroField({
  label,
  value,
  note,
  lead
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "v2-hero__field"
  }, /*#__PURE__*/React.createElement("span", {
    className: "v2-hero__label"
  }, label), /*#__PURE__*/React.createElement("span", {
    className: "v2-hero__value" + (lead ? " v2-hero__value--lead" : "")
  }, value), note ? /*#__PURE__*/React.createElement("span", {
    className: "v2-hero__note"
  }, note) : null);
}
function DetailScreen({
  go,
  params
}) {
  const item = findItem(params.itemId) || byStatus("ACTIVE")[0];
  const urgency = presentUrgency(item);
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(PageHeader, {
    above: /*#__PURE__*/React.createElement(BackLink, {
      onClick: e => {
        e.preventDefault();
        go("items");
      }
    }, "Voltar para Vencimentos"),
    title: item.name,
    badges: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Chip, {
      label: urgency.label,
      tone: urgency.tone
    }), /*#__PURE__*/React.createElement(Chip, {
      label: STATUS_LABEL[item.status],
      tone: "neutral",
      icon: "Circle"
    }), /*#__PURE__*/React.createElement(Tag, {
      text: item.category
    })),
    actions: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Button, {
      variant: "secondary",
      icon: "FileText",
      onClick: () => go("document", {
        itemId: item.itemId
      })
    }, "Documentos"), /*#__PURE__*/React.createElement(Button, {
      variant: "secondary",
      icon: "BellRing",
      onClick: () => go("alert", {
        itemId: item.itemId
      })
    }, "Alerta"), item.status === "ACTIVE" ? /*#__PURE__*/React.createElement(Button, {
      variant: "primary",
      icon: "RefreshCw",
      onClick: () => go("renew", {
        itemId: item.itemId
      })
    }, "Renovar") : null)
  }), params.justCreated ? /*#__PURE__*/React.createElement(InlineNotice, {
    tone: "success"
  }, /*#__PURE__*/React.createElement("p", null, "Vencimento criado com sucesso.")) : null, params.justRenewed ? /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(InlineNotice, {
    tone: "success"
  }, /*#__PURE__*/React.createElement("p", null, "Renova\xE7\xE3o conclu\xEDda \u2014 este \xE9 o novo ciclo.")), /*#__PURE__*/React.createElement(InlineNotice, {
    tone: "warning"
  }, /*#__PURE__*/React.createElement("p", null, "Os lembretes do ciclo anterior foram copiados. Revise se o prazo de aviso ainda faz sentido."))) : null, /*#__PURE__*/React.createElement("div", {
    className: "v2-hero"
  }, /*#__PURE__*/React.createElement(HeroField, {
    label: "Vencimento",
    value: formatAbsoluteDate(item.dueDate),
    note: formatRelativeDueContext(item.dueDate),
    lead: true
  }), /*#__PURE__*/React.createElement(HeroField, {
    label: "Periodicidade",
    value: item.periodicity || "—"
  }), /*#__PURE__*/React.createElement(HeroField, {
    label: "Emissor",
    value: item.issuer || "—"
  }), /*#__PURE__*/React.createElement(HeroField, {
    label: "Respons\xE1vel",
    value: item.assigneeUserId || "—"
  })), item.description ? /*#__PURE__*/React.createElement("div", {
    style: {
      marginBottom: 24,
      maxWidth: "68ch"
    }
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontSize: 14,
      color: "var(--v2-ink-700)",
      lineHeight: 1.6
    }
  }, item.description)) : null, /*#__PURE__*/React.createElement("div", {
    className: "v2-detail-grid"
  }, /*#__PURE__*/React.createElement(Panel, {
    padded: true
  }, /*#__PURE__*/React.createElement("h2", {
    className: "v2-panel__title",
    style: {
      marginBottom: 14,
      display: "flex",
      alignItems: "center",
      gap: 8
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "FileText",
    size: 16
  }), "Identifica\xE7\xE3o do documento"), /*#__PURE__*/React.createElement("dl", {
    className: "v2-detail-list"
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("dt", null, "Emissor"), /*#__PURE__*/React.createElement("dd", null, item.issuer || "—")), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("dt", null, "N\xFAmero"), /*#__PURE__*/React.createElement("dd", null, item.number || "—")), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("dt", null, "Periodicidade"), /*#__PURE__*/React.createElement("dd", null, item.periodicity || "—")), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("dt", null, "Tags"), /*#__PURE__*/React.createElement("dd", null, item.tags && item.tags.length ? item.tags.join(", ") : "—")))), /*#__PURE__*/React.createElement(Panel, {
    padded: true
  }, /*#__PURE__*/React.createElement("h2", {
    className: "v2-panel__title",
    style: {
      marginBottom: 14,
      display: "flex",
      alignItems: "center",
      gap: 8
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "Users",
    size: 16
  }), "Acompanhamento interno"), /*#__PURE__*/React.createElement("dl", {
    className: "v2-detail-list"
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("dt", null, "Respons\xE1vel"), /*#__PURE__*/React.createElement("dd", null, /*#__PURE__*/React.createElement(Person, {
    name: item.assigneeUserId || "—"
  }))), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("dt", null, "Prioridade"), /*#__PURE__*/React.createElement("dd", null, item.priority || "—")), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("dt", null, "Situa\xE7\xE3o"), /*#__PURE__*/React.createElement("dd", null, /*#__PURE__*/React.createElement(Chip, {
    label: STATUS_LABEL[item.status],
    tone: "neutral",
    icon: "Circle"
  })))))));
}
const EMPTY_DRAFT = {
  name: "",
  category: "",
  dueDate: "",
  description: "",
  issuer: "",
  number: "",
  periodicity: "",
  issueDate: "",
  assigneeUserId: "",
  priority: "",
  tags: ""
};
const LABELS = {
  name: "Nome",
  category: "Categoria",
  dueDate: "Data de vencimento"
};
function CreateScreen({
  go
}) {
  const [draft, setDraft] = React.useState(EMPTY_DRAFT);
  const [errors, setErrors] = React.useState({});
  const [pending, setPending] = React.useState(false);
  const set = field => value => setDraft(Object.assign({}, draft, {
    [field]: value
  }));
  const id = field => "create-item-" + field;
  function submit(event) {
    event.preventDefault();
    const next = {};
    if (!draft.name.trim()) next.name = "Informe o nome do vencimento.";
    if (!draft.category.trim()) next.category = "Informe a categoria.";
    if (!draft.dueDate) next.dueDate = "Informe a data de vencimento.";
    setErrors(next);
    if (Object.keys(next).length > 0) return;
    setPending(true);
    window.setTimeout(() => {
      setPending(false);
      go("detail", {
        itemId: "i-04",
        justCreated: true
      });
    }, 700);
  }
  const fieldErrors = Object.keys(errors).filter(k => LABELS[k]).map(k => ({
    fieldId: id(k),
    label: LABELS[k],
    message: errors[k]
  }));
  return /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 720
    }
  }, /*#__PURE__*/React.createElement(PageHeader, {
    above: /*#__PURE__*/React.createElement(BackLink, {
      onClick: e => {
        e.preventDefault();
        go("items");
      }
    }, "Voltar para Vencimentos"),
    title: "Novo vencimento",
    description: "S\xF3 nome, categoria e data de vencimento s\xE3o obrigat\xF3rios. O resto pode ser preenchido depois."
  }), /*#__PURE__*/React.createElement("form", {
    onSubmit: submit,
    noValidate: true
  }, /*#__PURE__*/React.createElement(FormErrorSummary, {
    errors: [],
    fieldErrors: fieldErrors
  }), /*#__PURE__*/React.createElement(Panel, {
    padded: true
  }, /*#__PURE__*/React.createElement("div", {
    className: "v2-form-section"
  }, /*#__PURE__*/React.createElement("div", {
    className: "v2-form-section__head"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "Sparkles"
  }), /*#__PURE__*/React.createElement("span", {
    className: "v2-form-section__title"
  }, "O essencial")), /*#__PURE__*/React.createElement("p", {
    className: "v2-form-section__desc"
  }, "O que \xE9, de que tipo \xE9, e quando vence."), /*#__PURE__*/React.createElement(TextField, {
    id: id("name"),
    label: "Nome",
    value: draft.name,
    onChange: set("name"),
    error: errors.name,
    required: true,
    maxLength: 200
  }), /*#__PURE__*/React.createElement("div", {
    className: "v2-form-grid"
  }, /*#__PURE__*/React.createElement(TextField, {
    id: id("category"),
    label: "Categoria",
    value: draft.category,
    onChange: set("category"),
    error: errors.category,
    required: true,
    width: "md",
    maxLength: 100
  }), /*#__PURE__*/React.createElement(TextField, {
    id: id("dueDate"),
    label: "Data de vencimento",
    type: "date",
    value: draft.dueDate,
    onChange: set("dueDate"),
    error: errors.dueDate,
    required: true,
    width: "date"
  })))), /*#__PURE__*/React.createElement("div", {
    style: {
      height: 16
    }
  }), /*#__PURE__*/React.createElement(Panel, {
    padded: true
  }, /*#__PURE__*/React.createElement("div", {
    className: "v2-form-section"
  }, /*#__PURE__*/React.createElement("div", {
    className: "v2-form-section__head"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "ListPlus"
  }), /*#__PURE__*/React.createElement("span", {
    className: "v2-form-section__title"
  }, "Complemento")), /*#__PURE__*/React.createElement("p", {
    className: "v2-form-section__desc"
  }, "Tudo aqui \xE9 opcional e pode ser preenchido depois."), /*#__PURE__*/React.createElement(TextField, {
    id: id("description"),
    label: "Descri\xE7\xE3o",
    value: draft.description,
    onChange: set("description"),
    multiline: true,
    maxLength: 2000
  }), /*#__PURE__*/React.createElement("div", {
    className: "v2-form-grid"
  }, /*#__PURE__*/React.createElement(TextField, {
    id: id("issuer"),
    label: "Emissor",
    value: draft.issuer,
    onChange: set("issuer"),
    width: "md",
    maxLength: 200
  }), /*#__PURE__*/React.createElement(TextField, {
    id: id("number"),
    label: "N\xFAmero",
    value: draft.number,
    onChange: set("number"),
    width: "sm",
    maxLength: 100
  }), /*#__PURE__*/React.createElement(TextField, {
    id: id("periodicity"),
    label: "Periodicidade",
    value: draft.periodicity,
    onChange: set("periodicity"),
    width: "sm",
    maxLength: 50
  }), /*#__PURE__*/React.createElement(TextField, {
    id: id("issueDate"),
    label: "Data de emiss\xE3o",
    type: "date",
    value: draft.issueDate,
    onChange: set("issueDate"),
    width: "date"
  }), /*#__PURE__*/React.createElement(TextField, {
    id: id("assigneeUserId"),
    label: "Respons\xE1vel",
    value: draft.assigneeUserId,
    onChange: set("assigneeUserId"),
    width: "md",
    maxLength: 100
  }), /*#__PURE__*/React.createElement(TextField, {
    id: id("priority"),
    label: "Prioridade",
    value: draft.priority,
    onChange: set("priority"),
    width: "sm",
    maxLength: 50
  })), /*#__PURE__*/React.createElement(TextField, {
    id: id("tags"),
    label: "Tags",
    value: draft.tags,
    onChange: set("tags"),
    hint: "Separadas por v\xEDrgula. Ex.: financeiro, contrato",
    width: "md"
  }))), /*#__PURE__*/React.createElement("div", {
    className: "v2-form-actions"
  }, /*#__PURE__*/React.createElement(Button, {
    type: "submit",
    variant: "primary",
    icon: pending ? undefined : "Check",
    pending: pending
  }, pending ? "Criando…" : "Criar vencimento"), /*#__PURE__*/React.createElement(Button, {
    variant: "tertiary",
    onClick: () => go("items")
  }, "Cancelar"))));
}
function RenewScreen({
  go,
  params
}) {
  const item = findItem(params.itemId) || byStatus("ACTIVE")[0];
  const [newDueDate, setNewDueDate] = React.useState("");
  const [conflict, setConflict] = React.useState(false);
  const [pending, setPending] = React.useState(false);
  const [generalErrors, setGeneralErrors] = React.useState([]);
  function submit(event) {
    event.preventDefault();
    if (conflict) return;
    if (!newDueDate) {
      setGeneralErrors(["Informe a nova data de vencimento."]);
      return;
    }
    setGeneralErrors([]);
    setPending(true);
    window.setTimeout(() => {
      setPending(false);
      go("detail", {
        itemId: item.itemId,
        justRenewed: true
      });
    }, 700);
  }
  return /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 720
    }
  }, /*#__PURE__*/React.createElement(PageHeader, {
    above: /*#__PURE__*/React.createElement(BackLink, {
      onClick: e => {
        e.preventDefault();
        go("detail", {
          itemId: item.itemId
        });
      }
    }, "Voltar para o vencimento"),
    title: "Renovar vencimento",
    description: /*#__PURE__*/React.createElement("strong", {
      style: {
        color: "var(--v2-ink-800)"
      }
    }, item.name)
  }), /*#__PURE__*/React.createElement("div", {
    className: "v2-hero"
  }, /*#__PURE__*/React.createElement(HeroField, {
    label: "Ciclo atual",
    value: formatAbsoluteDate(item.dueDate),
    note: formatRelativeDueContext(item.dueDate),
    lead: true
  }), /*#__PURE__*/React.createElement(HeroField, {
    label: "Periodicidade",
    value: item.periodicity || "—"
  }), /*#__PURE__*/React.createElement(HeroField, {
    label: "Emissor",
    value: item.issuer || "—"
  })), /*#__PURE__*/React.createElement(InlineNotice, {
    tone: "info",
    icon: "Info"
  }, /*#__PURE__*/React.createElement("p", null, "Renovar cria um novo ciclo: o atual (vencimento em ", formatAbsoluteDate(item.dueDate), ") ser\xE1 marcado como ", /*#__PURE__*/React.createElement("strong", null, "renovado"), " e um novo vencimento ativo ser\xE1 criado com a nova data.")), conflict ? /*#__PURE__*/React.createElement(InlineNotice, {
    tone: "warning",
    icon: "TriangleAlert",
    title: "Este vencimento mudou desde que voc\xEA o abriu",
    actions: /*#__PURE__*/React.createElement(Button, {
      variant: "secondary",
      size: "sm",
      icon: "RefreshCw",
      onClick: () => setConflict(false)
    }, "Recarregar")
  }, /*#__PURE__*/React.createElement("p", null, "Recarregue para ver o estado atual antes de renovar novamente.")) : null, /*#__PURE__*/React.createElement("form", {
    onSubmit: submit,
    noValidate: true,
    style: {
      marginTop: 20
    }
  }, /*#__PURE__*/React.createElement(FormErrorSummary, {
    errors: generalErrors
  }), /*#__PURE__*/React.createElement(TextField, {
    id: "renew-due-date",
    label: "Nova data de vencimento",
    type: "date",
    value: newDueDate,
    onChange: setNewDueDate,
    required: true,
    width: "date"
  }), /*#__PURE__*/React.createElement("div", {
    className: "v2-form-actions"
  }, /*#__PURE__*/React.createElement(Button, {
    type: "submit",
    variant: "primary",
    icon: pending ? undefined : "Check",
    pending: pending,
    disabled: conflict
  }, pending ? "Renovando…" : "Confirmar renovação"), /*#__PURE__*/React.createElement(Button, {
    variant: "tertiary",
    onClick: () => go("detail", {
      itemId: item.itemId
    })
  }, "Cancelar")), /*#__PURE__*/React.createElement("p", {
    style: {
      marginTop: 20,
      fontSize: 12.5,
      color: "var(--v2-ink-400)"
    }
  }, "Controle do UI kit (n\xE3o faz parte do produto): ", /*#__PURE__*/React.createElement("a", {
    href: "#",
    onClick: e => {
      e.preventDefault();
      setConflict(true);
    },
    style: {
      color: "var(--v2-ink-500)"
    }
  }, "simular conflito de vers\xE3o (409)"))));
}
Object.assign(window, {
  DetailScreen,
  CreateScreen,
  RenewScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/webapp/RecordScreens-v2.jsx", error: String((e && e.message) || e) }); }

// ui_kits/webapp/RecordScreens.jsx
try { (() => {
/* Detalhe, Novo vencimento e Renovar. */
const {
  Button,
  ButtonLink,
  Badge,
  InlineNotice,
  PageHeader,
  Panel,
  Section,
  DetailList,
  TextField,
  FormErrorSummary
} = window;
const {
  byStatus,
  presentUrgency,
  formatAbsoluteDate,
  formatRelativeDueContext,
  STATUS_LABEL
} = window;
function findItem(itemId) {
  return byStatus("ACTIVE").concat(byStatus("ARCHIVED"), byStatus("RENEWED")).find(i => i.itemId === itemId);
}
function HeroField({
  label,
  value,
  note,
  lead
}) {
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("span", {
    className: "ui-record-hero__label"
  }, label), /*#__PURE__*/React.createElement("span", {
    className: "ui-record-hero__value" + (lead ? " ui-record-hero__value--lead" : "")
  }, value), note ? /*#__PURE__*/React.createElement("span", {
    className: "ui-record-hero__note"
  }, note) : null);
}
function DetailScreen({
  go,
  params
}) {
  const item = findItem(params.itemId) || byStatus("ACTIVE")[0];
  const urgency = presentUrgency(item);
  return /*#__PURE__*/React.createElement("div", {
    className: "ui-page ui-page--record"
  }, /*#__PURE__*/React.createElement(PageHeader, {
    above: /*#__PURE__*/React.createElement("a", {
      href: "#",
      onClick: e => {
        e.preventDefault();
        go("items");
      }
    }, "\u2190 Voltar para Vencimentos"),
    title: item.name,
    badges: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Badge, {
      label: urgency.label,
      tone: urgency.tone,
      srPrefix: "Urg\xEAncia"
    }), /*#__PURE__*/React.createElement(Badge, {
      label: STATUS_LABEL[item.status],
      tone: "neutral",
      srPrefix: "Situa\xE7\xE3o"
    })),
    actions: item.status === "ACTIVE" ? /*#__PURE__*/React.createElement(Button, {
      variant: "primary",
      onClick: () => go("renew", {
        itemId: item.itemId
      })
    }, "Renovar") : null
  }), params.justCreated ? /*#__PURE__*/React.createElement(InlineNotice, {
    tone: "success",
    announce: "status"
  }, /*#__PURE__*/React.createElement("p", null, "Vencimento criado com sucesso.")) : null, params.justRenewed ? /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(InlineNotice, {
    tone: "success",
    announce: "status"
  }, /*#__PURE__*/React.createElement("p", null, "Renova\xE7\xE3o conclu\xEDda \u2014 este \xE9 o novo ciclo.")), /*#__PURE__*/React.createElement(InlineNotice, {
    tone: "warning",
    announce: "status"
  }, /*#__PURE__*/React.createElement("p", null, "Os lembretes do ciclo anterior foram copiados para este vencimento. Revise se o prazo de aviso ainda faz sentido."))) : null, /*#__PURE__*/React.createElement("div", {
    className: "ui-record-hero"
  }, /*#__PURE__*/React.createElement(HeroField, {
    label: "Vencimento",
    value: formatAbsoluteDate(item.dueDate),
    note: formatRelativeDueContext(item.dueDate),
    lead: true
  }), /*#__PURE__*/React.createElement(HeroField, {
    label: "Categoria",
    value: item.category
  }), /*#__PURE__*/React.createElement(HeroField, {
    label: "Periodicidade",
    value: item.periodicity || "—"
  }), /*#__PURE__*/React.createElement(HeroField, {
    label: "Respons\xE1vel",
    value: item.assigneeUserId || "—"
  })), item.description ? /*#__PURE__*/React.createElement(Section, {
    heading: "Descri\xE7\xE3o",
    headingId: "detail-description"
  }, /*#__PURE__*/React.createElement("p", {
    className: "u-reading-width",
    style: {
      textWrap: "pretty"
    }
  }, item.description)) : null, /*#__PURE__*/React.createElement("div", {
    className: "ui-detail-grid"
  }, /*#__PURE__*/React.createElement(Panel, {
    padded: true
  }, /*#__PURE__*/React.createElement("h2", {
    className: "ui-panel__title",
    style: {
      marginBottom: "12px"
    }
  }, "Identifica\xE7\xE3o do documento"), /*#__PURE__*/React.createElement(DetailList, {
    fields: [{
      label: "Emissor",
      value: item.issuer
    }, {
      label: "Número",
      value: item.number
    }, {
      label: "Periodicidade",
      value: item.periodicity
    }, {
      label: "Tags",
      value: item.tags && item.tags.length ? item.tags.join(", ") : undefined
    }]
  })), /*#__PURE__*/React.createElement(Panel, {
    padded: true
  }, /*#__PURE__*/React.createElement("h2", {
    className: "ui-panel__title",
    style: {
      marginBottom: "12px"
    }
  }, "Acompanhamento interno"), /*#__PURE__*/React.createElement(DetailList, {
    fields: [{
      label: "Responsável",
      value: item.assigneeUserId
    }, {
      label: "Prioridade",
      value: item.priority
    }, {
      label: "Situação",
      value: /*#__PURE__*/React.createElement(Badge, {
        label: STATUS_LABEL[item.status],
        tone: "neutral",
        inline: true
      })
    }, {
      label: "Vencimento",
      value: formatAbsoluteDate(item.dueDate) + " · " + formatRelativeDueContext(item.dueDate)
    }]
  }))));
}
const EMPTY_DRAFT = {
  name: "",
  category: "",
  dueDate: "",
  description: "",
  issuer: "",
  number: "",
  periodicity: "",
  issueDate: "",
  assigneeUserId: "",
  priority: "",
  tags: ""
};
const LABELS = {
  name: "Nome",
  category: "Categoria",
  dueDate: "Data de vencimento"
};
function CreateScreen({
  go
}) {
  const [draft, setDraft] = React.useState(EMPTY_DRAFT);
  const [errors, setErrors] = React.useState({});
  const [pending, setPending] = React.useState(false);
  const set = field => value => setDraft(Object.assign({}, draft, {
    [field]: value
  }));
  const id = field => "create-item-" + field;
  function submit(event) {
    event.preventDefault();
    const next = {};
    if (!draft.name.trim()) next.name = "Informe o nome do vencimento.";
    if (!draft.category.trim()) next.category = "Informe a categoria.";
    if (!draft.dueDate) next.dueDate = "Informe a data de vencimento.";
    setErrors(next);
    if (Object.keys(next).length > 0) return;
    setPending(true);
    window.setTimeout(() => {
      setPending(false);
      go("detail", {
        itemId: "i-04",
        justCreated: true
      });
    }, 700);
  }
  const fieldErrors = Object.keys(errors).filter(k => LABELS[k]).map(k => ({
    fieldId: id(k),
    label: LABELS[k],
    message: errors[k]
  }));
  return /*#__PURE__*/React.createElement("div", {
    className: "ui-page ui-page--record"
  }, /*#__PURE__*/React.createElement(PageHeader, {
    above: /*#__PURE__*/React.createElement("a", {
      href: "#",
      onClick: e => {
        e.preventDefault();
        go("items");
      }
    }, "\u2190 Voltar para Vencimentos"),
    title: "Novo vencimento",
    description: "S\xF3 nome, categoria e data de vencimento s\xE3o obrigat\xF3rios. O resto pode ser preenchido depois."
  }), /*#__PURE__*/React.createElement("form", {
    className: "ui-form ui-form--grouped",
    onSubmit: submit,
    noValidate: true
  }, /*#__PURE__*/React.createElement(FormErrorSummary, {
    errors: [],
    fieldErrors: fieldErrors
  }), /*#__PURE__*/React.createElement(Panel, {
    padded: true
  }, /*#__PURE__*/React.createElement("h2", {
    className: "ui-panel__title",
    style: {
      marginBottom: "4px"
    }
  }, "O essencial"), /*#__PURE__*/React.createElement("p", {
    className: "ui-section__description"
  }, "O que \xE9, de que tipo \xE9, e quando vence."), /*#__PURE__*/React.createElement(TextField, {
    id: id("name"),
    label: "Nome",
    value: draft.name,
    onChange: set("name"),
    error: errors.name,
    required: true,
    maxLength: 200
  }), /*#__PURE__*/React.createElement("div", {
    className: "ui-form__grid"
  }, /*#__PURE__*/React.createElement(TextField, {
    id: id("category"),
    label: "Categoria",
    value: draft.category,
    onChange: set("category"),
    error: errors.category,
    required: true,
    width: "md",
    maxLength: 100
  }), /*#__PURE__*/React.createElement(TextField, {
    id: id("dueDate"),
    label: "Data de vencimento",
    type: "date",
    value: draft.dueDate,
    onChange: set("dueDate"),
    error: errors.dueDate,
    required: true,
    width: "date"
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      height: "16px"
    }
  }), /*#__PURE__*/React.createElement(Panel, {
    padded: true
  }, /*#__PURE__*/React.createElement("h2", {
    className: "ui-panel__title",
    style: {
      marginBottom: "4px"
    }
  }, "Complemento"), /*#__PURE__*/React.createElement("p", {
    className: "ui-section__description"
  }, "Tudo aqui \xE9 opcional e pode ser preenchido depois, sem bloquear o acompanhamento."), /*#__PURE__*/React.createElement(TextField, {
    id: id("description"),
    label: "Descri\xE7\xE3o",
    value: draft.description,
    onChange: set("description"),
    multiline: true,
    maxLength: 2000
  }), /*#__PURE__*/React.createElement("div", {
    className: "ui-form__grid"
  }, /*#__PURE__*/React.createElement(TextField, {
    id: id("issuer"),
    label: "Emissor",
    value: draft.issuer,
    onChange: set("issuer"),
    width: "md",
    maxLength: 200
  }), /*#__PURE__*/React.createElement(TextField, {
    id: id("number"),
    label: "N\xFAmero",
    value: draft.number,
    onChange: set("number"),
    width: "sm",
    maxLength: 100
  }), /*#__PURE__*/React.createElement(TextField, {
    id: id("periodicity"),
    label: "Periodicidade",
    value: draft.periodicity,
    onChange: set("periodicity"),
    width: "sm",
    maxLength: 50
  }), /*#__PURE__*/React.createElement(TextField, {
    id: id("issueDate"),
    label: "Data de emiss\xE3o",
    type: "date",
    value: draft.issueDate,
    onChange: set("issueDate"),
    width: "date"
  }), /*#__PURE__*/React.createElement(TextField, {
    id: id("assigneeUserId"),
    label: "Respons\xE1vel",
    value: draft.assigneeUserId,
    onChange: set("assigneeUserId"),
    width: "md",
    maxLength: 100
  }), /*#__PURE__*/React.createElement(TextField, {
    id: id("priority"),
    label: "Prioridade",
    value: draft.priority,
    onChange: set("priority"),
    width: "sm",
    maxLength: 50
  })), /*#__PURE__*/React.createElement(TextField, {
    id: id("tags"),
    label: "Tags",
    value: draft.tags,
    onChange: set("tags"),
    hint: "Separadas por v\xEDrgula. Ex.: financeiro, contrato",
    width: "md"
  })), /*#__PURE__*/React.createElement("div", {
    className: "ui-form__actions"
  }, /*#__PURE__*/React.createElement(Button, {
    type: "submit",
    variant: "primary",
    pending: pending
  }, pending ? "Criando…" : "Criar vencimento"), /*#__PURE__*/React.createElement(Button, {
    variant: "tertiary",
    onClick: () => go("items")
  }, "Cancelar"))));
}
function RenewScreen({
  go,
  params
}) {
  const item = findItem(params.itemId) || byStatus("ACTIVE")[0];
  const [newDueDate, setNewDueDate] = React.useState("");
  const [conflict, setConflict] = React.useState(false);
  const [pending, setPending] = React.useState(false);
  const [generalErrors, setGeneralErrors] = React.useState([]);
  function submit(event) {
    event.preventDefault();
    if (conflict) return;
    if (!newDueDate) {
      setGeneralErrors(["Informe a nova data de vencimento."]);
      return;
    }
    setGeneralErrors([]);
    setPending(true);
    window.setTimeout(() => {
      setPending(false);
      go("detail", {
        itemId: item.itemId,
        justRenewed: true
      });
    }, 700);
  }
  return /*#__PURE__*/React.createElement("div", {
    className: "ui-page ui-page--record"
  }, /*#__PURE__*/React.createElement(PageHeader, {
    above: /*#__PURE__*/React.createElement("a", {
      href: "#",
      onClick: e => {
        e.preventDefault();
        go("detail", {
          itemId: item.itemId
        });
      }
    }, "\u2190 Voltar para o vencimento"),
    title: "Renovar vencimento",
    description: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("strong", null, item.name))
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: "60rem"
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "ui-record-hero"
  }, /*#__PURE__*/React.createElement(HeroField, {
    label: "Ciclo atual",
    value: formatAbsoluteDate(item.dueDate),
    note: formatRelativeDueContext(item.dueDate),
    lead: true
  }), /*#__PURE__*/React.createElement(HeroField, {
    label: "Periodicidade",
    value: item.periodicity || "—"
  }), /*#__PURE__*/React.createElement(HeroField, {
    label: "Emissor",
    value: item.issuer || "—"
  })), /*#__PURE__*/React.createElement(InlineNotice, {
    tone: "info"
  }, /*#__PURE__*/React.createElement("p", null, "Renovar cria um novo ciclo de vencimento: o ciclo atual (vencimento em ", formatAbsoluteDate(item.dueDate), ") ser\xE1 marcado como ", /*#__PURE__*/React.createElement("strong", null, "renovado"), " e um novo vencimento ativo ser\xE1 criado com a nova data. Isso n\xE3o \xE9 o mesmo que editar a data deste vencimento.")), conflict ? /*#__PURE__*/React.createElement(InlineNotice, {
    tone: "warning",
    announce: "alert",
    title: "Este vencimento mudou desde que voc\xEA o abriu",
    actions: /*#__PURE__*/React.createElement(Button, {
      variant: "secondary",
      onClick: () => setConflict(false)
    }, "Recarregar")
  }, /*#__PURE__*/React.createElement("p", null, "Recarregue para ver o estado atual antes de renovar novamente.")) : null, /*#__PURE__*/React.createElement("form", {
    className: "ui-form",
    onSubmit: submit,
    noValidate: true
  }, /*#__PURE__*/React.createElement(FormErrorSummary, {
    errors: generalErrors
  }), /*#__PURE__*/React.createElement(TextField, {
    id: "renew-due-date",
    label: "Nova data de vencimento",
    type: "date",
    value: newDueDate,
    onChange: setNewDueDate,
    required: true,
    width: "date"
  }), /*#__PURE__*/React.createElement("div", {
    className: "ui-form__actions"
  }, /*#__PURE__*/React.createElement(Button, {
    type: "submit",
    variant: "primary",
    pending: pending,
    disabled: conflict
  }, pending ? "Renovando…" : "Confirmar renovação"), /*#__PURE__*/React.createElement(Button, {
    variant: "tertiary",
    onClick: () => go("detail", {
      itemId: item.itemId
    })
  }, "Cancelar"))), /*#__PURE__*/React.createElement("p", {
    className: "u-text-secondary",
    style: {
      marginTop: "24px",
      fontSize: "13px"
    }
  }, "Controle do UI kit (n\xE3o faz parte do produto):", " ", /*#__PURE__*/React.createElement("a", {
    href: "#",
    onClick: e => {
      e.preventDefault();
      setConflict(true);
    }
  }, "simular conflito de vers\xE3o (409)"))));
}
Object.assign(window, {
  DetailScreen,
  CreateScreen,
  RenewScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/webapp/RecordScreens.jsx", error: String((e && e.message) || e) }); }

// ui_kits/webapp/SettingsAndImportScreens-v2.jsx
try { (() => {
const {
  Button,
  PageHeader,
  Panel,
  EmptyState,
  Chip
} = window;
function SettingsScreenV2() {
  const [emailReminders, setEmailReminders] = React.useState(true);
  const [deliveryDigest, setDeliveryDigest] = React.useState(false);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 640
    }
  }, /*#__PURE__*/React.createElement(PageHeader, {
    title: "Configura\xE7\xF5es",
    description: "Prefer\xEAncias de notifica\xE7\xE3o e entrega."
  }), /*#__PURE__*/React.createElement(Panel, {
    padded: true
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      padding: "14px 0",
      borderBottom: "1px solid var(--v2-ink-100)"
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 700,
      fontSize: 14
    }
  }, "Lembretes por e-mail"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12.5,
      color: "var(--v2-ink-500)"
    }
  }, "Receber alertas de vencimento no e-mail cadastrado.")), /*#__PURE__*/React.createElement("button", {
    onClick: () => setEmailReminders(!emailReminders),
    style: {
      width: 44,
      height: 26,
      borderRadius: 999,
      border: "none",
      cursor: "pointer",
      background: emailReminders ? "var(--v2-accent-600)" : "var(--v2-ink-200)",
      position: "relative",
      transition: "background-color .15s"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      position: "absolute",
      top: 3,
      left: emailReminders ? 21 : 3,
      width: 20,
      height: 20,
      borderRadius: "50%",
      background: "#fff",
      transition: "left .15s",
      boxShadow: "0 1px 3px rgba(0,0,0,.2)"
    }
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      padding: "14px 0"
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 700,
      fontSize: 14
    }
  }, "Resumo di\xE1rio"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12.5,
      color: "var(--v2-ink-500)"
    }
  }, "Agrupar avisos do dia em um s\xF3 e-mail, em vez de imediato.")), /*#__PURE__*/React.createElement("button", {
    onClick: () => setDeliveryDigest(!deliveryDigest),
    style: {
      width: 44,
      height: 26,
      borderRadius: 999,
      border: "none",
      cursor: "pointer",
      background: deliveryDigest ? "var(--v2-accent-600)" : "var(--v2-ink-200)",
      position: "relative",
      transition: "background-color .15s"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      position: "absolute",
      top: 3,
      left: deliveryDigest ? 21 : 3,
      width: 20,
      height: 20,
      borderRadius: "50%",
      background: "#fff",
      transition: "left .15s",
      boxShadow: "0 1px 3px rgba(0,0,0,.2)"
    }
  })))));
}
function ImportFlowScreenV2({
  go
}) {
  const [stage, setStage] = React.useState("upload");
  function upload() {
    setStage("parsing");
    window.setTimeout(() => setStage("preview"), 1200);
  }
  function commit() {
    setStage("committing");
    window.setTimeout(() => setStage("done"), 900);
  }
  return /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 720
    }
  }, /*#__PURE__*/React.createElement(PageHeader, {
    title: "Importar planilha",
    description: "Traga vencimentos existentes de uma planilha CSV."
  }), /*#__PURE__*/React.createElement(Panel, {
    padded: true
  }, stage === "upload" ? /*#__PURE__*/React.createElement(EmptyState, {
    icon: "UploadCloud",
    title: "Envie um arquivo CSV",
    message: "Colunas esperadas: nome, categoria, data de vencimento.",
    action: /*#__PURE__*/React.createElement(Button, {
      variant: "primary",
      icon: "Upload",
      onClick: upload
    }, "Selecionar arquivo")
  }) : stage === "parsing" ? /*#__PURE__*/React.createElement(EmptyState, {
    icon: "Loader2",
    title: "Lendo o arquivo\u2026",
    message: "Isso leva alguns segundos."
  }) : stage === "preview" ? /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 24,
      marginBottom: 20
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 24,
      fontWeight: 800
    }
  }, "48"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      color: "var(--v2-ink-500)"
    }
  }, "linhas lidas")), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 24,
      fontWeight: 800,
      color: "var(--v2-green-600)"
    }
  }, "44"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      color: "var(--v2-ink-500)"
    }
  }, "prontas")), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 24,
      fontWeight: 800,
      color: "var(--v2-amber-600)"
    }
  }, "3"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      color: "var(--v2-ink-500)"
    }
  }, "duplicadas")), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 24,
      fontWeight: 800,
      color: "var(--v2-red-600)"
    }
  }, "1"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      color: "var(--v2-ink-500)"
    }
  }, "rejeitada"))), /*#__PURE__*/React.createElement(window.InlineNotice, {
    tone: "warning",
    icon: "Info"
  }, /*#__PURE__*/React.createElement("p", null, "Erros de linha individuais n\xE3o s\xE3o detalhados nesta etapa \u2014 s\xF3 a contagem agregada.")), /*#__PURE__*/React.createElement("div", {
    className: "v2-form-actions"
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    icon: "Check",
    onClick: commit
  }, "Confirmar importa\xE7\xE3o (44 itens)"), /*#__PURE__*/React.createElement(Button, {
    variant: "tertiary",
    onClick: () => setStage("upload")
  }, "Cancelar"))) : stage === "committing" ? /*#__PURE__*/React.createElement(EmptyState, {
    icon: "Loader2",
    title: "Importando\u2026",
    message: "Criando os vencimentos."
  }) : /*#__PURE__*/React.createElement(EmptyState, {
    icon: "CircleCheck",
    title: "Importa\xE7\xE3o conclu\xEDda",
    message: "44 vencimentos foram criados.",
    action: /*#__PURE__*/React.createElement(Button, {
      variant: "primary",
      onClick: () => go("items")
    }, "Ver vencimentos")
  })));
}
Object.assign(window, {
  SettingsScreenV2,
  ImportFlowScreenV2
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/webapp/SettingsAndImportScreens-v2.jsx", error: String((e && e.message) || e) }); }

// ui_kits/webapp/SubjectScreens-v2.jsx
try { (() => {
const {
  Button,
  Chip,
  PageHeader,
  BackLink,
  Panel,
  DataTable,
  EmptyState
} = window;
const {
  SUBJECTS,
  subjectRequirements,
  requirementRequests,
  subjectPendingCount,
  REQ_STATUS_LABEL,
  REQUEST_STATUS_LABEL
} = window;
function findSubject(id) {
  return SUBJECTS.find(s => s.subjectId === id) || SUBJECTS[0];
}
function findRequirement(id) {
  return window.REQUIREMENTS.find(r => r.requirementId === id);
}
function SubjectCollectionScreen({
  go
}) {
  const columns = [{
    key: "name",
    header: "Fornecedor",
    render: s => /*#__PURE__*/React.createElement("div", {
      className: "v2-table__name"
    }, /*#__PURE__*/React.createElement("a", {
      href: "#",
      onClick: e => {
        e.preventDefault();
        go("subject-detail", {
          subjectId: s.subjectId
        });
      }
    }, s.name), /*#__PURE__*/React.createElement("span", {
      className: "v2-table__secondary"
    }, s.cnpj))
  }, {
    key: "kind",
    header: "Tipo",
    render: s => /*#__PURE__*/React.createElement("span", {
      style: {
        color: "var(--v2-ink-600)",
        fontWeight: 600
      }
    }, s.kind)
  }, {
    key: "req",
    header: "Requisitos",
    render: s => /*#__PURE__*/React.createElement("span", {
      style: {
        color: "var(--v2-ink-600)"
      }
    }, subjectRequirements(s.subjectId).length, " no total")
  }, {
    key: "pending",
    header: "Pendentes",
    render: s => {
      const n = subjectPendingCount(s.subjectId);
      return n > 0 ? /*#__PURE__*/React.createElement(Chip, {
        label: n + " pendente" + (n > 1 ? "s" : ""),
        tone: "warning",
        icon: "Clock"
      }) : /*#__PURE__*/React.createElement(Chip, {
        label: "Tudo vinculado",
        tone: "success",
        icon: "CircleCheck"
      });
    }
  }, {
    key: "actions",
    header: "",
    actions: true,
    render: s => /*#__PURE__*/React.createElement(Button, {
      variant: "tertiary",
      size: "sm",
      icon: "ChevronRight",
      onClick: () => go("subject-detail", {
        subjectId: s.subjectId
      })
    }, "Ver")
  }];
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(PageHeader, {
    title: "Fornecedores",
    description: "Terceiros que precisam manter documenta\xE7\xE3o em dia com voc\xEA.",
    actions: /*#__PURE__*/React.createElement(Button, {
      variant: "primary",
      icon: "Plus"
    }, "Novo fornecedor")
  }), /*#__PURE__*/React.createElement(Panel, {
    header: /*#__PURE__*/React.createElement("span", {
      className: "v2-panel__count"
    }, SUBJECTS.length, " fornecedores")
  }, /*#__PURE__*/React.createElement(DataTable, {
    caption: "Fornecedores",
    columns: columns,
    rows: SUBJECTS,
    rowKey: s => s.subjectId
  })));
}
function SubjectDetailScreen({
  go,
  params
}) {
  const subject = findSubject(params.subjectId);
  const reqs = subjectRequirements(subject.subjectId);
  const columns = [{
    key: "name",
    header: "Requisito",
    render: r => /*#__PURE__*/React.createElement("a", {
      href: "#",
      onClick: e => {
        e.preventDefault();
        go("requirement-detail", {
          requirementId: r.requirementId
        });
      },
      style: {
        color: "var(--v2-ink-900)",
        fontWeight: 700,
        textDecoration: "none"
      }
    }, r.name)
  }, {
    key: "status",
    header: "Status",
    render: r => /*#__PURE__*/React.createElement(Chip, {
      label: REQ_STATUS_LABEL[r.status],
      tone: r.status === "SATISFIED" ? "success" : "warning",
      icon: r.status === "SATISFIED" ? "CircleCheck" : "Clock"
    })
  }, {
    key: "actions",
    header: "",
    actions: true,
    render: r => /*#__PURE__*/React.createElement(Button, {
      variant: "tertiary",
      size: "sm",
      icon: "ChevronRight",
      onClick: () => go("requirement-detail", {
        requirementId: r.requirementId
      })
    }, "Ver")
  }];
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(PageHeader, {
    above: /*#__PURE__*/React.createElement(BackLink, {
      onClick: e => {
        e.preventDefault();
        go("subjects");
      }
    }, "Voltar para Fornecedores"),
    title: subject.name,
    badges: /*#__PURE__*/React.createElement(Chip, {
      label: subject.kind,
      tone: "neutral",
      icon: "Building2"
    }),
    description: "CNPJ " + subject.cnpj + " · " + subject.contact,
    actions: /*#__PURE__*/React.createElement(Button, {
      variant: "secondary",
      icon: "Send"
    }, "Solicitar documento")
  }), /*#__PURE__*/React.createElement(Panel, {
    header: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("h2", {
      className: "v2-panel__title"
    }, "Requisitos"), /*#__PURE__*/React.createElement("span", {
      className: "v2-panel__count"
    }, reqs.length, " no total"))
  }, reqs.length === 0 ? /*#__PURE__*/React.createElement(EmptyState, {
    icon: "ClipboardList",
    title: "Nenhum requisito",
    message: "Este fornecedor ainda n\xE3o tem requisitos configurados."
  }) : /*#__PURE__*/React.createElement(DataTable, {
    caption: "Requisitos do fornecedor",
    columns: columns,
    rows: reqs,
    rowKey: r => r.requirementId
  })));
}
function RequirementDetailScreen({
  go,
  params
}) {
  const requirement = findRequirement(params.requirementId) || window.REQUIREMENTS[0];
  const subject = findSubject(requirement.subjectId);
  const requests = requirementRequests(requirement.requirementId);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 860
    }
  }, /*#__PURE__*/React.createElement(PageHeader, {
    above: /*#__PURE__*/React.createElement(BackLink, {
      onClick: e => {
        e.preventDefault();
        go("subject-detail", {
          subjectId: subject.subjectId
        });
      }
    }, "Voltar para ", subject.name),
    title: requirement.name,
    badges: /*#__PURE__*/React.createElement(Chip, {
      label: window.REQ_STATUS_LABEL[requirement.status],
      tone: requirement.status === "SATISFIED" ? "success" : "warning"
    }),
    actions: /*#__PURE__*/React.createElement(Button, {
      variant: "primary",
      icon: "Send",
      onClick: () => go("subject-detail", {
        subjectId: subject.subjectId
      })
    }, "Nova solicita\xE7\xE3o")
  }), requirement.status === "SATISFIED" ? /*#__PURE__*/React.createElement(window.InlineNotice, {
    tone: "success",
    icon: "Link2"
  }, /*#__PURE__*/React.createElement("p", null, "Vinculado ao vencimento ", /*#__PURE__*/React.createElement("a", {
    href: "#",
    onClick: e => {
      e.preventDefault();
      go("detail", {
        itemId: requirement.linkedItemId
      });
    },
    style: {
      color: "inherit",
      fontWeight: 700
    }
  }, "ver vencimento"), ". V\xEDnculo confirmado manualmente.")) : /*#__PURE__*/React.createElement(window.InlineNotice, {
    tone: "warning",
    icon: "Clock"
  }, /*#__PURE__*/React.createElement("p", null, "Ainda n\xE3o h\xE1 documento vinculado a este requisito.")), /*#__PURE__*/React.createElement(Panel, {
    padded: true
  }, /*#__PURE__*/React.createElement("h2", {
    className: "v2-panel__title",
    style: {
      marginBottom: 14
    }
  }, "Solicita\xE7\xF5es enviadas"), requests.length === 0 ? /*#__PURE__*/React.createElement(EmptyState, {
    icon: "Send",
    title: "Nenhuma solicita\xE7\xE3o ainda",
    message: "Envie uma solicita\xE7\xE3o para que o fornecedor fa\xE7a o upload do documento."
  }) : /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 10
    }
  }, requests.map(r => /*#__PURE__*/React.createElement("div", {
    key: r.requestId,
    style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      gap: 16,
      padding: "14px 16px",
      border: "1px solid var(--v2-ink-100)",
      borderRadius: "var(--v2-radius-md)"
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 700,
      fontSize: 13.5
    }
  }, "Enviada em ", r.sentAt), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12.5,
      color: "var(--v2-ink-500)"
    }
  }, "Prazo: ", r.deadline)), /*#__PURE__*/React.createElement(Chip, {
    label: window.REQUEST_STATUS_LABEL[r.status],
    tone: r.status === "SUBMITTED" ? "success" : r.status === "REVOKED" ? "neutral" : "info"
  }))))));
}
Object.assign(window, {
  SubjectCollectionScreen,
  SubjectDetailScreen,
  RequirementDetailScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/webapp/SubjectScreens-v2.jsx", error: String((e && e.message) || e) }); }

// ui_kits/webapp/app-v2.jsx
try { (() => {
const NAV = [{
  key: "overview",
  label: "Visão geral",
  icon: "LayoutDashboard"
}, {
  key: "items",
  label: "Vencimentos",
  icon: "CalendarClock"
}, {
  key: "subjects",
  label: "Fornecedores",
  icon: "Building2"
}, {
  key: "settings",
  label: "Configurações",
  icon: "Settings"
}];
const RECORD_ROUTES = ["detail", "create", "renew", "subject-detail", "requirement-detail", "document", "alert", "import"];
function App() {
  if (window.location.hash === "#guest") return /*#__PURE__*/React.createElement(window.GuestSubmissionScreen, null);
  const [route, setRoute] = React.useState({
    name: "overview",
    params: {}
  });
  function go(name, params) {
    setRoute({
      name,
      params: params || {}
    });
    window.scrollTo(0, 0);
  }
  const itemRoutes = ["detail", "create", "renew", "document", "alert"];
  const subjectRoutes = ["subject-detail", "requirement-detail"];
  const active = itemRoutes.includes(route.name) ? "items" : subjectRoutes.includes(route.name) ? "subjects" : route.name === "import" ? "items" : route.name;
  const isRecord = RECORD_ROUTES.includes(route.name);
  const overdueCount = window.byStatus("ACTIVE").filter(i => window.presentUrgency(i).group === "overdue").length;
  const screen = route.name === "overview" ? /*#__PURE__*/React.createElement(window.OverviewScreen, {
    go: go
  }) : route.name === "items" ? /*#__PURE__*/React.createElement(window.CollectionScreen, {
    go: go
  }) : route.name === "detail" ? /*#__PURE__*/React.createElement(window.DetailScreen, {
    go: go,
    params: route.params
  }) : route.name === "create" ? /*#__PURE__*/React.createElement(window.CreateScreen, {
    go: go
  }) : route.name === "renew" ? /*#__PURE__*/React.createElement(window.RenewScreen, {
    go: go,
    params: route.params
  }) : route.name === "document" ? /*#__PURE__*/React.createElement(window.DocumentContextScreen, {
    go: go,
    params: route.params
  }) : route.name === "alert" ? /*#__PURE__*/React.createElement(window.AlertConfigurationScreen, {
    go: go,
    params: route.params
  }) : route.name === "subjects" ? /*#__PURE__*/React.createElement(window.SubjectCollectionScreen, {
    go: go
  }) : route.name === "subject-detail" ? /*#__PURE__*/React.createElement(window.SubjectDetailScreen, {
    go: go,
    params: route.params
  }) : route.name === "requirement-detail" ? /*#__PURE__*/React.createElement(window.RequirementDetailScreen, {
    go: go,
    params: route.params
  }) : route.name === "import" ? /*#__PURE__*/React.createElement(window.ImportFlowScreenV2, {
    go: go
  }) : /*#__PURE__*/React.createElement(window.SettingsScreenV2, null);
  return /*#__PURE__*/React.createElement("div", {
    className: "v2 v2-shell"
  }, /*#__PURE__*/React.createElement("nav", {
    className: "v2-rail",
    "aria-label": "Navega\xE7\xE3o principal"
  }, /*#__PURE__*/React.createElement("div", {
    className: "v2-brand"
  }, /*#__PURE__*/React.createElement("span", {
    className: "v2-brand__mark"
  }, "ET"), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "v2-brand__name"
  }, "Expiration Tracker"), /*#__PURE__*/React.createElement("div", {
    className: "v2-brand__sub"
  }, "Workspace \xB7 Matriz"))), /*#__PURE__*/React.createElement("div", {
    className: "v2-nav-group-label"
  }, "Principal"), NAV.map(n => /*#__PURE__*/React.createElement("a", {
    key: n.key,
    href: "#",
    className: "v2-nav-item",
    "aria-current": active === n.key ? "page" : undefined,
    onClick: e => {
      e.preventDefault();
      go(n.key);
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: n.icon
  }), /*#__PURE__*/React.createElement("span", {
    className: "label"
  }, n.label), n.key === "items" && overdueCount > 0 ? /*#__PURE__*/React.createElement("span", {
    className: "v2-nav-item__badge"
  }, overdueCount) : null)), /*#__PURE__*/React.createElement("span", {
    className: "v2-rail-spacer"
  }), /*#__PURE__*/React.createElement("div", {
    className: "v2-nav-group-label"
  }, "Utilit\xE1rios"), /*#__PURE__*/React.createElement("a", {
    href: "#",
    className: "v2-nav-item",
    onClick: e => {
      e.preventDefault();
      go("import");
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "UploadCloud"
  }), /*#__PURE__*/React.createElement("span", {
    className: "label"
  }, "Importar CSV")), /*#__PURE__*/React.createElement("div", {
    className: "v2-rail-footer"
  }, /*#__PURE__*/React.createElement(window.Avatar, {
    name: "Marcelo Gon\xE7alves",
    size: 34
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      minWidth: 0,
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "v2-user__name"
  }, "Marcelo Gon\xE7alves"), /*#__PURE__*/React.createElement("div", {
    className: "v2-user__role"
  }, "Administrador")), /*#__PURE__*/React.createElement("button", {
    className: "v2-icon-btn",
    "aria-label": "Sair"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "LogOut"
  })))), /*#__PURE__*/React.createElement("main", {
    className: "v2-main" + (isRecord ? " v2-main--record" : "")
  }, screen));
}
ReactDOM.createRoot(document.getElementById("root")).render(/*#__PURE__*/React.createElement(App, null));
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/webapp/app-v2.jsx", error: String((e && e.message) || e) }); }

// ui_kits/webapp/app.jsx
try { (() => {
const {
  Button,
  EmptyState
} = window;
const NAV = [{
  key: "overview",
  label: "Visão geral"
}, {
  key: "items",
  label: "Vencimentos"
}, {
  key: "subjects",
  label: "Fornecedores"
}, {
  key: "settings",
  label: "Configurações"
}];
function SubjectsScreen() {
  return /*#__PURE__*/React.createElement("div", {
    className: "ui-page"
  }, /*#__PURE__*/React.createElement(window.PageHeader, {
    title: "Fornecedores",
    description: "Entrada da revis\xE3o de requisitos por fornecedor."
  }), /*#__PURE__*/React.createElement(EmptyState, {
    kind: "not-ready",
    message: "Esta superf\xEDcie existe no frontend de produ\xE7\xE3o, mas ainda \xE9 estrutural: nenhuma linguagem visual foi aplicada a ela. Reproduzi-la aqui com o visual das outras telas seria inventar um design que o produto n\xE3o tem."
  }));
}
function SettingsScreen() {
  return /*#__PURE__*/React.createElement("div", {
    className: "ui-page"
  }, /*#__PURE__*/React.createElement(window.PageHeader, {
    title: "Configura\xE7\xF5es"
  }), /*#__PURE__*/React.createElement(EmptyState, {
    kind: "not-ready",
    message: "Esta tela ainda n\xE3o foi implementada no frontend de produ\xE7\xE3o nesta etapa."
  }));
}
function App() {
  const [route, setRoute] = React.useState({
    name: "overview",
    params: {}
  });
  const mainRef = React.useRef(null);
  function go(name, params) {
    setRoute({
      name,
      params: params || {}
    });
    if (mainRef.current) mainRef.current.scrollTop = 0;
    window.scrollTo(0, 0);
  }
  const active = route.name === "detail" || route.name === "create" || route.name === "renew" ? "items" : route.name;
  const screen = route.name === "overview" ? /*#__PURE__*/React.createElement(window.OverviewScreen, {
    go: go
  }) : route.name === "items" ? /*#__PURE__*/React.createElement(window.CollectionScreen, {
    go: go
  }) : route.name === "detail" ? /*#__PURE__*/React.createElement(window.DetailScreen, {
    go: go,
    params: route.params
  }) : route.name === "create" ? /*#__PURE__*/React.createElement(window.CreateScreen, {
    go: go
  }) : route.name === "renew" ? /*#__PURE__*/React.createElement(window.RenewScreen, {
    go: go,
    params: route.params
  }) : route.name === "subjects" ? /*#__PURE__*/React.createElement(SubjectsScreen, null) : /*#__PURE__*/React.createElement(SettingsScreen, null);
  return /*#__PURE__*/React.createElement("div", {
    className: "app-shell"
  }, /*#__PURE__*/React.createElement("a", {
    href: "#surface-content",
    className: "skip-link"
  }, "Pular para o conte\xFAdo"), /*#__PURE__*/React.createElement("nav", {
    className: "app-shell__nav",
    "aria-label": "Navega\xE7\xE3o principal"
  }, /*#__PURE__*/React.createElement("span", {
    className: "app-shell__wordmark"
  }, "Expiration Tracker"), NAV.map(n => /*#__PURE__*/React.createElement("a", {
    key: n.key,
    href: "#",
    className: "app-shell__link",
    "aria-current": active === n.key ? "page" : undefined,
    onClick: e => {
      e.preventDefault();
      go(n.key);
    }
  }, n.label)), /*#__PURE__*/React.createElement("span", {
    className: "app-shell__nav-spacer"
  }), /*#__PURE__*/React.createElement("div", {
    className: "app-shell__nav-footer"
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "tertiary",
    size: "sm"
  }, "Sair"))), /*#__PURE__*/React.createElement("main", {
    className: "app-shell__main",
    id: "surface-content",
    tabIndex: -1,
    ref: mainRef
  }, screen));
}
ReactDOM.createRoot(document.getElementById("root")).render(/*#__PURE__*/React.createElement(App, null));
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/webapp/app.jsx", error: String((e && e.message) || e) }); }

// ui_kits/webapp/data-subjects.jsx
try { (() => {
/* Fornecedores + Requisitos + Solicitações — dataset fake para o UI kit. */
const REQ_STATUS_LABEL = {
  MISSING: "Pendente",
  SATISFIED: "Vinculado"
};
const REQUEST_STATUS_LABEL = {
  REQUESTED: "Enviada",
  OPENED: "Aberta pelo fornecedor",
  SUBMITTED: "Documento recebido",
  REVOKED: "Revogada"
};
function subject(id, name, kind, extra) {
  return Object.assign({
    subjectId: id,
    name,
    kind
  }, extra || {});
}
function requirement(id, subjectId, name, status, extra) {
  return Object.assign({
    requirementId: id,
    subjectId,
    name,
    status,
    requests: []
  }, extra || {});
}
function docRequest(id, requirementId, status, extra) {
  return Object.assign({
    requestId: id,
    requirementId,
    status
  }, extra || {});
}
const SUBJECTS = [subject("s-01", "Conservare Facilities ME", "Prestador de serviço", {
  cnpj: "14.221.900/0001-55",
  contact: "contato@conservare.com.br"
}), subject("s-02", "Atlas Schindler", "Prestador de serviço", {
  cnpj: "58.470.834/0001-27",
  contact: "atendimento@atlasschindler.com"
}), subject("s-03", "Porto Seguro", "Seguradora", {
  cnpj: "61.198.164/0001-60",
  contact: "corporate@portoseguro.com.br"
}), subject("s-04", "Imobiliária Vértice", "Locador", {
  cnpj: "22.884.410/0001-02",
  contact: "juridico@vertiximob.com.br"
}), subject("s-05", "Comerc Energia", "Fornecedor de energia", {
  cnpj: "09.071.232/0001-88",
  contact: "suprimento@comercenergia.com.br"
})];
const REQUIREMENTS = [requirement("r-01", "s-01", "Certidão Negativa de Débitos Trabalhistas", "MISSING"), requirement("r-02", "s-01", "Apólice de Seguro de Responsabilidade Civil", "SATISFIED", {
  linkedItemId: "i-13"
}), requirement("r-03", "s-02", "Certificado de Manutenção NR-12", "MISSING"), requirement("r-04", "s-02", "Contrato vigente assinado", "SATISFIED", {
  linkedItemId: "i-09"
}), requirement("r-05", "s-03", "Apólice vigente", "SATISFIED", {
  linkedItemId: "i-06"
}), requirement("r-06", "s-04", "Contrato de locação vigente", "SATISFIED", {
  linkedItemId: "i-12"
}), requirement("r-07", "s-04", "Comprovante de regularidade do imóvel (IPTU)", "MISSING"), requirement("r-08", "s-05", "Contrato de fornecimento vigente", "SATISFIED", {
  linkedItemId: "i-16"
})];
const DOC_REQUESTS = [docRequest("dr-01", "r-01", "OPENED", {
  subjectName: "Conservare Facilities ME",
  requirementName: "Certidão Negativa de Débitos Trabalhistas",
  sentAt: "2026-08-20",
  deadline: "2026-09-03"
}), docRequest("dr-02", "r-03", "REQUESTED", {
  subjectName: "Atlas Schindler",
  requirementName: "Certificado de Manutenção NR-12",
  sentAt: "2026-08-24",
  deadline: "2026-09-07"
}), docRequest("dr-03", "r-07", "SUBMITTED", {
  subjectName: "Imobiliária Vértice",
  requirementName: "Comprovante de regularidade do imóvel (IPTU)",
  sentAt: "2026-08-10",
  deadline: "2026-08-24"
})];
function subjectRequirements(subjectId) {
  return REQUIREMENTS.filter(r => r.subjectId === subjectId);
}
function requirementRequests(requirementId) {
  return DOC_REQUESTS.filter(r => r.requirementId === requirementId);
}
function subjectPendingCount(subjectId) {
  return subjectRequirements(subjectId).filter(r => r.status === "MISSING").length;
}
Object.assign(window, {
  SUBJECTS,
  REQUIREMENTS,
  DOC_REQUESTS,
  REQ_STATUS_LABEL,
  REQUEST_STATUS_LABEL,
  subjectRequirements,
  requirementRequests,
  subjectPendingCount
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/webapp/data-subjects.jsx", error: String((e && e.message) || e) }); }

// ui_kits/webapp/data.jsx
try { (() => {
/* Fake dataset for the click-through. pt-BR domain vocabulary, fixed clock so every render is
   reproducible. */
const TODAY = new Date("2026-08-26T00:00:00.000Z");
const MS_PER_DAY = 86400000;
function dateOnlyUtc(iso) {
  return Date.parse(iso.slice(0, 10) + "T00:00:00.000Z");
}
function daysUntil(iso, now = TODAY) {
  return Math.round((dateOnlyUtc(iso) - dateOnlyUtc(now.toISOString())) / MS_PER_DAY);
}
function formatAbsoluteDate(iso) {
  const [y, m, d] = iso.slice(0, 10).split("-");
  return d + "/" + m + "/" + y;
}
function formatRelativeDueContext(iso, now = TODAY) {
  const n = daysUntil(iso, now);
  if (n < 0) {
    const o = Math.abs(n);
    return "Venceu " + (o === 1 ? "há 1 dia" : "há " + o + " dias");
  }
  if (n === 0) return "Vence hoje";
  return "Vence em " + (n === 1 ? "1 dia" : n + " dias");
}
function presentUrgency(item, now = TODAY) {
  if (item.status !== "ACTIVE") return {
    label: "Não se aplica",
    tone: "neutral",
    group: "later"
  };
  const n = daysUntil(item.dueDate, now);
  if (n < 0) return {
    label: "Vencido",
    tone: "critical",
    group: "overdue"
  };
  if (n === 0) return {
    label: "Vence hoje",
    tone: "warning",
    group: "soon"
  };
  if (n <= 7) return {
    label: n === 1 ? "Vence em 1 dia" : "Vence em " + n + " dias",
    tone: "warning",
    group: "soon"
  };
  return {
    label: "Sem urgência",
    tone: "success",
    group: "later"
  };
}
const STATUS_LABEL = {
  ACTIVE: "Ativo",
  ARCHIVED: "Arquivado",
  RENEWED: "Renovado"
};

/* Paleta determinística de tags por categoria — 6 tons, escolhidos pelo hash do nome. */
const TAG_PALETTE = [{
  bg: "#ede9fe",
  fg: "#6d28d9"
}, {
  bg: "#dbeafe",
  fg: "#1d4ed8"
}, {
  bg: "#dcfce7",
  fg: "#15803d"
}, {
  bg: "#fef3c7",
  fg: "#b45309"
}, {
  bg: "#fce7f3",
  fg: "#be185d"
}, {
  bg: "#e0f2fe",
  fg: "#0369a1"
}];
function tagColor(text) {
  let h = 0;
  for (let i = 0; i < text.length; i++) h = h * 31 + text.charCodeAt(i) >>> 0;
  return TAG_PALETTE[h % TAG_PALETTE.length];
}
const AVATAR_PALETTE = ["#7c3aed", "#2563eb", "#16a34a", "#d97706", "#db2777", "#0891b2"];
function avatarColor(text) {
  let h = 0;
  for (let i = 0; i < text.length; i++) h = h * 31 + text.charCodeAt(i) >>> 0;
  return AVATAR_PALETTE[h % AVATAR_PALETTE.length];
}
function initials(name) {
  const parts = name.trim().split(/\s+/);
  return ((parts[0] || "")[0] || "") + ((parts[1] || "")[0] || "");
}
function item(id, name, category, dueDate, extra) {
  return Object.assign({
    itemId: id,
    name,
    category,
    dueDate,
    status: "ACTIVE",
    tags: []
  }, extra || {});
}
const ITEMS = [item("i-01", "Contrato de Prestação de Serviços de Limpeza e Conservação Predial Continuada", "Contratos", "2026-08-20", {
  issuer: "Conservare Facilities ME",
  number: "CT-2024-0188",
  periodicity: "Anual",
  priority: "Alta",
  assigneeUserId: "Marcelo Gonçalves",
  tags: ["facilities", "contrato"],
  description: "Contrato continuado com reajuste anual por IPCA. A renovação exige aviso prévio de 60 dias."
}), item("i-02", "Alvará de Funcionamento — Unidade Centro (1ª via)", "Licenças", "2026-08-25", {
  issuer: "Prefeitura Municipal",
  number: "2024/003919",
  periodicity: "Anual",
  priority: "Alta",
  assigneeUserId: "Ana Ribeiro",
  tags: ["obrigatório"]
}), item("i-03", "Certificado Digital e-CNPJ A3", "Certificados", "2026-08-29", {
  issuer: "Serasa Experian",
  number: "A3-77120945",
  periodicity: "Trienal",
  priority: "Alta",
  assigneeUserId: "Marcelo Gonçalves",
  tags: ["fiscal"],
  description: "Token físico sob guarda do setor fiscal. Renovação presencial com validação biométrica."
}), item("i-04", "Licença de Operação Ambiental — Renovação Quadrienal do Estabelecimento Industrial", "Licenças", "2026-08-31", {
  issuer: "Companhia Ambiental do Estado",
  number: "2024/00918",
  periodicity: "Quadrienal",
  priority: "Alta",
  assigneeUserId: "Paulo Menezes",
  tags: ["ambiental", "obrigatório"],
  description: "Renovação obrigatória junto ao órgão ambiental estadual. Exige protocolo com 120 dias de antecedência."
}), item("i-05", "AVCB — Auto de Vistoria do Corpo de Bombeiros (1ª via)", "Licenças", "2026-09-02", {
  issuer: "Corpo de Bombeiros Militar",
  number: "AVCB-118422",
  periodicity: "Trienal",
  priority: "Alta",
  assigneeUserId: "Ana Ribeiro",
  tags: ["segurança"]
}), item("i-06", "Apólice de Seguro Patrimonial", "Seguros", "2026-09-09", {
  issuer: "Porto Seguro",
  number: "APL-9022441",
  periodicity: "Anual",
  priority: "Média",
  assigneeUserId: "Ana Ribeiro",
  tags: ["patrimônio"]
}), item("i-07", "Alvará de Funcionamento — Unidade Zona Sul", "Licenças", "2026-09-06", {
  issuer: "Prefeitura Municipal",
  number: "2024/004102",
  periodicity: "Anual",
  priority: "Média",
  assigneeUserId: "Ana Ribeiro"
}), item("i-08", "Certificado Digital e-CNPJ A1", "Certificados", "2026-09-07", {
  issuer: "Certisign",
  number: "A1-4409112",
  periodicity: "Anual",
  priority: "Média",
  assigneeUserId: "Marcelo Gonçalves"
}), item("i-09", "Contrato de Manutenção Preventiva de Elevadores", "Contratos", "2026-09-21", {
  issuer: "Atlas Schindler",
  number: "CT-2025-0042",
  periodicity: "Anual",
  priority: "Média",
  assigneeUserId: "Paulo Menezes"
}), item("i-10", "Certificado de Regularidade do FGTS", "Certidões", "2026-09-24", {
  issuer: "Caixa Econômica Federal",
  number: "CRF-2026-118",
  periodicity: "Trimestral",
  priority: "Alta",
  assigneeUserId: "Bianca Souza"
}), item("i-11", "Certidão Negativa de Débitos Federais", "Certidões", "2026-10-02", {
  issuer: "Receita Federal",
  number: "CND-90441",
  periodicity: "Semestral",
  priority: "Alta",
  assigneeUserId: "Bianca Souza"
}), item("i-12", "Contrato de Locação — Galpão Logístico Guarulhos", "Contratos", "2026-10-15", {
  issuer: "Imobiliária Vértice",
  number: "LOC-8871",
  periodicity: "Trienal",
  priority: "Alta",
  assigneeUserId: "Marcelo Gonçalves"
}), item("i-13", "Apólice de Responsabilidade Civil Geral", "Seguros", "2026-10-30", {
  issuer: "Tokio Marine",
  number: "APL-3390127",
  periodicity: "Anual",
  priority: "Média",
  assigneeUserId: "Ana Ribeiro"
}), item("i-14", "Licença Sanitária — Cozinha Industrial", "Licenças", "2026-11-11", {
  issuer: "Vigilância Sanitária Municipal",
  number: "VS-2025-771",
  periodicity: "Anual",
  priority: "Alta",
  assigneeUserId: "Paulo Menezes"
}), item("i-15", "Certificado ISO 9001:2015", "Certificados", "2026-12-04", {
  issuer: "Bureau Veritas",
  number: "ISO-441209",
  periodicity: "Trienal",
  priority: "Baixa",
  assigneeUserId: "Bianca Souza"
}), item("i-16", "Contrato de Fornecimento de Energia — Mercado Livre", "Contratos", "2027-01-31", {
  issuer: "Comerc Energia",
  number: "CT-2024-0301",
  periodicity: "Bienal",
  priority: "Média",
  assigneeUserId: "Marcelo Gonçalves"
}), item("i-17", "Apólice de Seguro de Frota", "Seguros", "2027-02-18", {
  issuer: "Bradesco Seguros",
  number: "APL-7781200",
  periodicity: "Anual",
  priority: "Baixa",
  assigneeUserId: "Paulo Menezes"
}), item("i-18", "Alvará de Publicidade — Fachada Unidade Centro", "Licenças", "2027-03-09", {
  issuer: "Prefeitura Municipal",
  number: "PUB-2026-055",
  periodicity: "Anual",
  priority: "Baixa",
  assigneeUserId: "Ana Ribeiro"
})];
const ARCHIVED = [Object.assign({}, ITEMS[5], {
  itemId: "a-01",
  name: "Apólice de Seguro Patrimonial (ciclo 2024/2025)",
  dueDate: "2025-09-09",
  status: "ARCHIVED"
}), Object.assign({}, ITEMS[1], {
  itemId: "a-02",
  name: "Alvará de Funcionamento — Unidade Centro (ciclo 2024)",
  dueDate: "2025-08-25",
  status: "ARCHIVED"
})];
const RENEWED = [Object.assign({}, ITEMS[2], {
  itemId: "r-01",
  name: "Certificado Digital e-CNPJ A3 (ciclo anterior)",
  dueDate: "2026-08-29",
  status: "RENEWED"
}), Object.assign({}, ITEMS[9], {
  itemId: "r-02",
  name: "Certificado de Regularidade do FGTS (2º trimestre)",
  dueDate: "2026-06-24",
  status: "RENEWED"
})];
function byStatus(status) {
  if (status === "ARCHIVED") return ARCHIVED;
  if (status === "RENEWED") return RENEWED;
  return ITEMS;
}
function sortByDueDateAscending(items) {
  return [...items].sort((a, b) => a.dueDate < b.dueDate ? -1 : a.dueDate > b.dueDate ? 1 : 0);
}
Object.assign(window, {
  TODAY,
  ITEMS,
  byStatus,
  sortByDueDateAscending,
  presentUrgency,
  formatAbsoluteDate,
  formatRelativeDueContext,
  daysUntil,
  STATUS_LABEL,
  tagColor,
  avatarColor,
  initials
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/webapp/data.jsx", error: String((e && e.message) || e) }); }

// ui_kits/webapp/icon.jsx
try { (() => {
/* Ponte para o Lucide (CDN, carregado no <head> do index.html). Usa a API createElement do
   Lucide para gerar o SVG real e o insere via ref — nunca via innerHTML/dangerouslySet — para
   que o React nunca precise reconciliar o conteúdo interno do ícone. */
function Icon({
  name,
  size = 18,
  className = "",
  strokeWidth = 2
}) {
  const ref = React.useRef(null);
  React.useEffect(() => {
    const L = window.lucide;
    if (!L || !ref.current) return;
    const node = L.icons && L.icons[name];
    if (!node) return;
    ref.current.innerHTML = "";
    const svg = L.createElement(node);
    svg.setAttribute("width", size);
    svg.setAttribute("height", size);
    svg.setAttribute("stroke-width", strokeWidth);
    ref.current.appendChild(svg);
  });
  return /*#__PURE__*/React.createElement("span", {
    ref: ref,
    className: "icon " + className,
    style: {
      display: "inline-flex",
      width: size,
      height: size
    },
    "aria-hidden": "true"
  });
}
window.Icon = Icon;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/webapp/icon.jsx", error: String((e && e.message) || e) }); }

// ui_kits/webapp/ui-v2.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/* Primitivos visuais v2 — SaaS moderno, ícones Lucide, sombras suaves, cor com propósito. */

function Button({
  variant = "secondary",
  size = "md",
  pending,
  disabled,
  icon,
  children,
  ...rest
}) {
  const cls = ["v2-btn", "v2-btn--" + variant, size === "sm" ? "v2-btn--sm" : ""].filter(Boolean).join(" ");
  return /*#__PURE__*/React.createElement("button", _extends({}, rest, {
    type: rest.type || "button",
    className: cls,
    disabled: Boolean(disabled || pending)
  }), pending ? /*#__PURE__*/React.createElement(Icon, {
    name: "Loader2",
    className: "v2-spin"
  }) : icon ? /*#__PURE__*/React.createElement(Icon, {
    name: icon
  }) : null, children);
}
function ButtonLink({
  variant = "secondary",
  size = "md",
  icon,
  children,
  ...rest
}) {
  const cls = ["v2-btn", "v2-btn--" + variant, size === "sm" ? "v2-btn--sm" : ""].filter(Boolean).join(" ");
  return /*#__PURE__*/React.createElement("a", _extends({}, rest, {
    href: rest.href || "#",
    className: cls
  }), icon ? /*#__PURE__*/React.createElement(Icon, {
    name: icon
  }) : null, children);
}
const TONE_ICON = {
  critical: "CircleAlert",
  warning: "Clock",
  success: "CircleCheck",
  info: "Info",
  neutral: "Circle"
};
function Chip({
  label,
  tone = "neutral",
  icon,
  ghost
}) {
  const cls = "v2-chip " + (ghost ? "v2-chip--ghost" : "v2-chip--" + tone);
  return /*#__PURE__*/React.createElement("span", {
    className: cls
  }, /*#__PURE__*/React.createElement(Icon, {
    name: icon || TONE_ICON[tone] || "Circle",
    size: 13
  }), label);
}
function Tag({
  text
}) {
  const c = window.tagColor(text);
  return /*#__PURE__*/React.createElement("span", {
    className: "v2-tag",
    style: {
      background: c.bg,
      color: c.fg
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "dot"
  }), text);
}
function Avatar({
  name,
  size = 24
}) {
  const bg = window.avatarColor(name);
  return /*#__PURE__*/React.createElement("span", {
    className: "v2-mini-avatar",
    style: {
      background: bg,
      width: size,
      height: size,
      fontSize: size * 0.42
    }
  }, window.initials(name));
}
function Person({
  name
}) {
  return /*#__PURE__*/React.createElement("span", {
    className: "v2-person"
  }, /*#__PURE__*/React.createElement(Avatar, {
    name: name
  }), name);
}
function InlineNotice({
  tone = "info",
  title,
  children,
  actions,
  icon
}) {
  const cls = "v2-notice v2-notice--" + tone;
  return /*#__PURE__*/React.createElement("div", {
    className: cls
  }, /*#__PURE__*/React.createElement(Icon, {
    name: icon || TONE_ICON[tone] || "Info"
  }), /*#__PURE__*/React.createElement("div", {
    className: "v2-notice__body"
  }, title ? /*#__PURE__*/React.createElement("p", {
    className: "v2-notice__title"
  }, title) : null, children, actions ? /*#__PURE__*/React.createElement("div", {
    className: "v2-notice__actions"
  }, actions) : null));
}
function PageHeader({
  title,
  description,
  above,
  actions,
  badges
}) {
  return /*#__PURE__*/React.createElement("header", {
    className: "v2-page-header"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      minWidth: 0
    }
  }, above, /*#__PURE__*/React.createElement("h1", null, title), badges ? /*#__PURE__*/React.createElement("div", {
    className: "v2-page-header__badges"
  }, badges) : null, description ? /*#__PURE__*/React.createElement("p", {
    className: "v2-page-header__desc"
  }, description) : null), actions ? /*#__PURE__*/React.createElement("div", {
    className: "v2-page-header__actions"
  }, actions) : null);
}
function BackLink({
  href = "#",
  children,
  onClick
}) {
  return /*#__PURE__*/React.createElement("a", {
    href: href,
    className: "v2-page-header__back",
    onClick: onClick
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "ArrowLeft",
    size: 15
  }), children);
}
function Panel({
  children,
  padded,
  header,
  footer
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "v2-panel"
  }, header ? /*#__PURE__*/React.createElement("div", {
    className: "v2-panel__header"
  }, header) : null, /*#__PURE__*/React.createElement("div", {
    className: padded ? "v2-panel--padded" : ""
  }, children), footer ? /*#__PURE__*/React.createElement("div", {
    className: "v2-panel__footer"
  }, footer) : null);
}
function FilterGroup({
  label,
  options,
  value,
  onChange
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "v2-filter",
    role: "group",
    "aria-label": label
  }, options.map(o => /*#__PURE__*/React.createElement("button", {
    key: o.value,
    type: "button",
    className: "v2-filter__opt",
    "aria-pressed": o.value === value,
    onClick: () => onChange(o.value)
  }, o.label)));
}
function cellClass(c) {
  return c.actions ? "v2-table__actions" : "";
}
function DataTable({
  caption,
  columns,
  rows,
  groups,
  rowKey,
  density
}) {
  const renderRow = row => /*#__PURE__*/React.createElement("tr", {
    key: rowKey(row)
  }, columns.map(c => /*#__PURE__*/React.createElement("td", {
    key: c.key,
    className: cellClass(c)
  }, c.render(row))));
  const cls = "v2-table" + (density === "compact" ? " v2-table--compact" : "");
  return /*#__PURE__*/React.createElement("div", {
    className: "v2-table-wrap"
  }, /*#__PURE__*/React.createElement("table", {
    className: cls
  }, /*#__PURE__*/React.createElement("caption", {
    className: "u-visually-hidden",
    style: {
      position: "absolute",
      width: 1,
      height: 1,
      overflow: "hidden"
    }
  }, caption), /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", null, columns.map(c => /*#__PURE__*/React.createElement("th", {
    key: c.key,
    className: cellClass(c)
  }, c.actions ? "" : c.header)))), groups ? groups.map(g => /*#__PURE__*/React.createElement("tbody", {
    key: g.id
  }, /*#__PURE__*/React.createElement("tr", {
    className: "v2-table__group"
  }, /*#__PURE__*/React.createElement("th", {
    colSpan: columns.length
  }, g.label, /*#__PURE__*/React.createElement("span", {
    className: "v2-table__group-count"
  }, g.rows.length))), g.rows.map(renderRow))) : /*#__PURE__*/React.createElement("tbody", null, (rows || []).map(renderRow))));
}
function TextField({
  label,
  value,
  onChange,
  error,
  hint,
  required,
  type = "text",
  multiline,
  id,
  width,
  maxLength,
  icon
}) {
  const props = {
    id,
    className: "v2-field__control",
    value,
    maxLength,
    required,
    onChange: e => onChange(e.target.value)
  };
  return /*#__PURE__*/React.createElement("div", {
    className: "v2-field" + (error ? " v2-field--invalid" : ""),
    "data-width": width
  }, /*#__PURE__*/React.createElement("label", {
    className: "v2-field__label",
    htmlFor: id
  }, label, " ", /*#__PURE__*/React.createElement("span", {
    className: "v2-field__req"
  }, required ? "obrigatório" : "opcional")), hint ? /*#__PURE__*/React.createElement("p", {
    className: "v2-field__hint"
  }, hint) : null, multiline ? /*#__PURE__*/React.createElement("textarea", props) : /*#__PURE__*/React.createElement("input", _extends({}, props, {
    type: type
  })), error ? /*#__PURE__*/React.createElement("p", {
    className: "v2-field__error"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "CircleAlert",
    size: 13
  }), error) : null);
}
function FormErrorSummary({
  errors = [],
  fieldErrors = []
}) {
  if (!errors.length && !fieldErrors.length) return null;
  return /*#__PURE__*/React.createElement("div", {
    className: "v2-error-summary"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "CircleAlert"
  }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("p", {
    className: "v2-error-summary__title"
  }, "Corrija os seguintes problemas"), /*#__PURE__*/React.createElement("ul", null, fieldErrors.map(fe => /*#__PURE__*/React.createElement("li", {
    key: fe.fieldId
  }, /*#__PURE__*/React.createElement("a", {
    href: "#" + fe.fieldId
  }, fe.label, ": ", fe.message))), errors.map((m, i) => /*#__PURE__*/React.createElement("li", {
    key: i
  }, m)))));
}
function EmptyState({
  icon = "Inbox",
  title,
  message,
  action
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "v2-empty"
  }, /*#__PURE__*/React.createElement("div", {
    className: "v2-empty__icon"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: icon
  })), title ? /*#__PURE__*/React.createElement("p", {
    className: "v2-empty__title"
  }, title) : null, /*#__PURE__*/React.createElement("p", {
    className: "v2-empty__message"
  }, message), action);
}
function RefreshIndicator({
  label = "Atualizando"
}) {
  return /*#__PURE__*/React.createElement("span", {
    className: "v2-refresh"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "RefreshCw",
    size: 14
  }), label, "\u2026");
}
Object.assign(window, {
  Button,
  ButtonLink,
  Chip,
  Tag,
  Avatar,
  Person,
  InlineNotice,
  PageHeader,
  BackLink,
  Panel,
  FilterGroup,
  DataTable,
  TextField,
  FormErrorSummary,
  EmptyState,
  RefreshIndicator
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/webapp/ui-v2.jsx", error: String((e && e.message) || e) }); }

// ui_kits/webapp/ui.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/* Cosmetic stand-ins for the design-system primitives in /components, mounted against the
   same class names and the same CSS. The kit is a recreation of the product's screens, not a
   second implementation of its behaviour. */

function Button({
  variant = "secondary",
  size = "md",
  pending,
  disabled,
  type = "button",
  children,
  ...rest
}) {
  const cls = ["ui-button", "ui-button--" + variant, size === "sm" ? "ui-button--sm" : ""].filter(Boolean).join(" ");
  return /*#__PURE__*/React.createElement("button", _extends({}, rest, {
    type: type,
    className: cls,
    disabled: Boolean(disabled || pending),
    "data-pending": pending ? "true" : undefined,
    "aria-busy": pending || undefined
  }), children);
}
function ButtonLink({
  variant = "secondary",
  size = "md",
  children,
  ...rest
}) {
  const cls = ["ui-button", "ui-button--" + variant, size === "sm" ? "ui-button--sm" : "", "ui-button--as-link"].filter(Boolean).join(" ");
  return /*#__PURE__*/React.createElement("a", _extends({}, rest, {
    href: rest.href || "#",
    className: cls
  }), children);
}
function Badge({
  label,
  tone = "neutral",
  srPrefix,
  inline,
  wrap
}) {
  const cls = ["ui-badge", "ui-badge--" + tone, inline ? "ui-badge--inline" : "", wrap ? "ui-badge--wrap" : ""].filter(Boolean).join(" ");
  return /*#__PURE__*/React.createElement("span", {
    className: cls,
    "data-tone": tone
  }, /*#__PURE__*/React.createElement("span", {
    className: "ui-badge__marker",
    "aria-hidden": "true"
  }), srPrefix ? /*#__PURE__*/React.createElement("span", {
    className: "u-visually-hidden"
  }, srPrefix, ": ") : null, label);
}
const NOTICE_MARKER = {
  neutral: "\u2022",
  info: "i",
  success: "\u2713",
  warning: "!",
  critical: "\u00d7"
};
function InlineNotice({
  tone = "info",
  title,
  children,
  actions,
  announce = "none"
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "ui-notice ui-notice--" + tone,
    role: announce === "none" ? undefined : announce,
    "aria-live": announce === "status" ? "polite" : undefined
  }, /*#__PURE__*/React.createElement("span", {
    className: "ui-notice__marker",
    "aria-hidden": "true"
  }, NOTICE_MARKER[tone]), /*#__PURE__*/React.createElement("div", {
    className: "ui-notice__body"
  }, title ? /*#__PURE__*/React.createElement("p", {
    className: "ui-notice__title"
  }, title) : null, children, actions ? /*#__PURE__*/React.createElement("div", {
    className: "ui-notice__actions"
  }, actions) : null));
}
function PageHeader({
  title,
  description,
  above,
  actions,
  badges
}) {
  return /*#__PURE__*/React.createElement("header", {
    className: "ui-page-header"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ui-page-header__text"
  }, above ? /*#__PURE__*/React.createElement("div", {
    className: "ui-page-header__back"
  }, above) : null, /*#__PURE__*/React.createElement("h1", null, title), badges ? /*#__PURE__*/React.createElement("div", {
    className: "ui-page-header__badges"
  }, badges) : null, description ? /*#__PURE__*/React.createElement("p", {
    className: "ui-page-header__description"
  }, description) : null), actions ? /*#__PURE__*/React.createElement("div", {
    className: "ui-page-header__actions"
  }, actions) : null);
}
function Panel({
  children,
  padded,
  header,
  footer,
  tall
}) {
  const cls = ["ui-panel", padded ? "ui-panel--padded" : "", tall ? "ui-panel--tall" : ""].filter(Boolean).join(" ");
  return /*#__PURE__*/React.createElement("div", {
    className: cls
  }, header ? /*#__PURE__*/React.createElement("div", {
    className: "ui-panel__header"
  }, header) : null, children, footer ? /*#__PURE__*/React.createElement("div", {
    className: "ui-panel__footer"
  }, footer) : null);
}
function Section({
  heading,
  headingId,
  description,
  children
}) {
  return /*#__PURE__*/React.createElement("section", {
    className: "ui-section",
    "aria-labelledby": headingId
  }, /*#__PURE__*/React.createElement("h2", {
    id: headingId,
    className: "ui-section__heading"
  }, heading), description ? /*#__PURE__*/React.createElement("p", {
    className: "ui-section__description"
  }, description) : null, children);
}
function FilterGroup({
  label,
  options,
  value,
  onChange
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "ui-filter",
    role: "group",
    "aria-label": label
  }, options.map(o => /*#__PURE__*/React.createElement("button", {
    key: o.value,
    type: "button",
    className: "ui-filter__option",
    "aria-pressed": o.value === value,
    onClick: () => onChange(o.value)
  }, o.label)));
}
function CellSecondary({
  children
}) {
  return /*#__PURE__*/React.createElement("span", {
    className: "ui-table__secondary"
  }, children);
}
function cellClass(c) {
  if (c.primary) return "ui-table__cell--primary";
  if (c.actions) return "ui-table__cell--actions";
  if (c.numeric) return "ui-table__cell--numeric";
  return "";
}
function DataTable({
  caption,
  columns,
  rows,
  groups,
  rowKey,
  density = "comfortable",
  stickyHeader
}) {
  const renderRow = row => /*#__PURE__*/React.createElement("tr", {
    key: rowKey(row)
  }, columns.map(c => /*#__PURE__*/React.createElement("td", {
    key: c.key,
    className: cellClass(c),
    "data-label": c.primary || c.actions ? undefined : c.header
  }, c.render(row))));
  const cls = ["ui-table", density === "compact" ? "ui-table--compact" : "", stickyHeader ? "ui-table--sticky" : ""].filter(Boolean).join(" ");
  return /*#__PURE__*/React.createElement("div", {
    className: "ui-table-scroll"
  }, /*#__PURE__*/React.createElement("table", {
    className: cls
  }, /*#__PURE__*/React.createElement("caption", {
    className: "u-visually-hidden"
  }, caption), /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", null, columns.map(c => /*#__PURE__*/React.createElement("th", {
    key: c.key,
    scope: "col",
    className: cellClass(c)
  }, c.actions ? /*#__PURE__*/React.createElement("span", {
    className: "u-visually-hidden"
  }, c.header) : c.header)))), groups ? groups.map(g => /*#__PURE__*/React.createElement("tbody", {
    key: g.id
  }, /*#__PURE__*/React.createElement("tr", {
    className: "ui-table__group-header"
  }, /*#__PURE__*/React.createElement("th", {
    scope: "rowgroup",
    colSpan: columns.length
  }, g.label, /*#__PURE__*/React.createElement("span", {
    className: "ui-table__group-count"
  }, g.rows.length))), g.rows.map(renderRow))) : /*#__PURE__*/React.createElement("tbody", null, (rows || []).map(renderRow))));
}
function DetailList({
  fields
}) {
  const present = fields.filter(x => Boolean(x.value));
  if (!present.length) return null;
  return /*#__PURE__*/React.createElement("dl", {
    className: "ui-detail-list"
  }, present.map(x => /*#__PURE__*/React.createElement("div", {
    key: x.label
  }, /*#__PURE__*/React.createElement("dt", null, x.label), /*#__PURE__*/React.createElement("dd", null, x.value))));
}
function TextField({
  label,
  value,
  onChange,
  error,
  hint,
  required,
  type = "text",
  multiline,
  id,
  width,
  maxLength
}) {
  const errorId = id + "-error";
  const hintId = id + "-hint";
  const describedBy = [hint ? hintId : null, error ? errorId : null].filter(Boolean).join(" ") || undefined;
  const props = {
    id,
    className: "ui-field__control",
    value,
    maxLength,
    required,
    "aria-invalid": error ? true : undefined,
    "aria-describedby": describedBy,
    onChange: e => onChange(e.target.value)
  };
  return /*#__PURE__*/React.createElement("div", {
    className: "ui-field" + (error ? " ui-field--invalid" : ""),
    "data-width": width
  }, /*#__PURE__*/React.createElement("label", {
    className: "ui-field__label",
    htmlFor: id
  }, label, " ", /*#__PURE__*/React.createElement("span", {
    className: "ui-field__requirement"
  }, required ? "(obrigatório)" : "(opcional)")), hint ? /*#__PURE__*/React.createElement("p", {
    className: "ui-field__hint",
    id: hintId
  }, hint) : null, multiline ? /*#__PURE__*/React.createElement("textarea", props) : /*#__PURE__*/React.createElement("input", _extends({}, props, {
    type: type
  })), error ? /*#__PURE__*/React.createElement("p", {
    className: "ui-field__error",
    id: errorId,
    role: "alert"
  }, error) : null);
}
function FormErrorSummary({
  errors = [],
  fieldErrors = []
}) {
  if (!errors.length && !fieldErrors.length) return null;
  const single = errors.length === 1 && !fieldErrors.length;
  return /*#__PURE__*/React.createElement("div", {
    className: "ui-error-summary",
    role: "alert"
  }, single ? /*#__PURE__*/React.createElement("p", {
    className: "ui-error-summary__title"
  }, errors[0]) : /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("p", {
    className: "ui-error-summary__title"
  }, "Corrija os seguintes problemas:"), /*#__PURE__*/React.createElement("ul", {
    className: "ui-error-summary__list"
  }, fieldErrors.map(fe => /*#__PURE__*/React.createElement("li", {
    key: fe.fieldId
  }, /*#__PURE__*/React.createElement("a", {
    href: "#" + fe.fieldId
  }, fe.label, ": ", fe.message))), errors.map((m, i) => /*#__PURE__*/React.createElement("li", {
    key: i
  }, m)))));
}
function BackgroundRefreshIndicator({
  label = "Atualizando…"
}) {
  return /*#__PURE__*/React.createElement("span", {
    className: "ui-refresh-indicator",
    role: "status",
    "aria-live": "polite"
  }, /*#__PURE__*/React.createElement("span", {
    className: "ui-refresh-indicator__dot",
    "aria-hidden": "true"
  }), label);
}
function EmptyState({
  kind,
  message,
  action
}) {
  const titles = {
    "true-empty": "Comece por aqui",
    "filtered-empty": "Nenhum resultado",
    unavailable: "Conteúdo indisponível",
    "permission-limited": "Acesso restrito"
  };
  return /*#__PURE__*/React.createElement("div", {
    className: "ui-async-block",
    "data-empty-kind": kind
  }, titles[kind] ? /*#__PURE__*/React.createElement("p", {
    className: "ui-async-block__title"
  }, titles[kind]) : null, /*#__PURE__*/React.createElement("p", {
    className: "ui-async-block__message"
  }, message), action ? /*#__PURE__*/React.createElement("div", {
    className: "ui-async-block__actions"
  }, action) : null);
}
Object.assign(window, {
  Button,
  ButtonLink,
  Badge,
  InlineNotice,
  PageHeader,
  Panel,
  Section,
  FilterGroup,
  DataTable,
  CellSecondary,
  DetailList,
  TextField,
  FormErrorSummary,
  BackgroundRefreshIndicator,
  EmptyState
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/webapp/ui.jsx", error: String((e && e.message) || e) }); }

__ds_ns.Button = __ds_scope.Button;

__ds_ns.ButtonLink = __ds_scope.ButtonLink;

__ds_ns.Icon = __ds_scope.Icon;

__ds_ns.InlineNotice = __ds_scope.InlineNotice;

__ds_ns.StatusBadge = __ds_scope.StatusBadge;

__ds_ns.UrgencyIndicator = __ds_scope.UrgencyIndicator;

__ds_ns.DataTable = __ds_scope.DataTable;

__ds_ns.CellSecondary = __ds_scope.CellSecondary;

__ds_ns.AsyncFeedback = __ds_scope.AsyncFeedback;

__ds_ns.BackgroundRefreshIndicator = __ds_scope.BackgroundRefreshIndicator;

__ds_ns.CollectionSkeleton = __ds_scope.CollectionSkeleton;

__ds_ns.EmptyState = __ds_scope.EmptyState;

__ds_ns.ErrorState = __ds_scope.ErrorState;

__ds_ns.InitialLoading = __ds_scope.InitialLoading;

__ds_ns.FormErrorSummary = __ds_scope.FormErrorSummary;

__ds_ns.TextField = __ds_scope.TextField;

__ds_ns.DetailList = __ds_scope.DetailList;

__ds_ns.FilterGroup = __ds_scope.FilterGroup;

__ds_ns.PageHeader = __ds_scope.PageHeader;

__ds_ns.Panel = __ds_scope.Panel;

__ds_ns.Section = __ds_scope.Section;

__ds_ns.Toolbar = __ds_scope.Toolbar;

__ds_ns.ToolbarSpacer = __ds_scope.ToolbarSpacer;

__ds_ns.AppShell = __ds_scope.AppShell;

})();
